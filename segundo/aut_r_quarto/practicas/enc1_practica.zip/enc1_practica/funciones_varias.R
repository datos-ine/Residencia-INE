calculo_edad <- function(fecha_nacimiento, fecha) {
  
  if (!"lubridate" %in% installed.packages()) {
    install.packages("lubridate")  
  }  
  
  require(lubridate) # suprime los mensajes
  
  if (is.character(fecha_nacimiento)) {
    fecha_nacimiento <- dmy(fecha_nacimiento)
  }  
  
  if (is.character(fecha)) {
    fecha <- dmy(fecha)
  }  
  
  interval(fecha_nacimiento, fecha)%/% dyears()
  
}

resumen <- function(datos, var) {
  
  if (!"dplyr" %in% installed.packages()) {
    install.packages("dplyr")  
  }  
  
  require(dplyr)
  
  datos |> summarise(
    min = min({{ var }}, na.rm = TRUE),
    media = mean({{ var }}, na.rm = TRUE),
    mediana = median({{ var }}, na.rm = TRUE),
    max = max({{ var }}, na.rm = TRUE),
    n = n(),
    n_NA = sum(is.na({{ var }}))
  )
}

barras_ordenadas <- function(datos, var) {
  
  if (!"tidyverse" %in% installed.packages()) {
    install.packages("tidyverse")  
  }  
  
  require(tidyverse)
  
  datos |> 
    mutate({{ var }} := fct_infreq({{ var }}))  |>
    ggplot(aes(x = {{ var }}, fill = {{ var }})) +
    geom_bar() +
    scale_fill_brewer(palette = "Dark2") +
    theme(legend.position = "bottom")
}