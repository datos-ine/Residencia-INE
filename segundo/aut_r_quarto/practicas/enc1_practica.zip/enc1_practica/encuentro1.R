library(tidyverse)

# vectorizacion

log(1)

numeros <- 1:5

log(numeros)

# condicionales

# if() - else()

casos <- 10

if (casos > 100) {
  estado <- "Alerta"
} else {
  estado <- "Sin alerta"
}

estado

casos <- 110

if (casos > 100) {
  estado <- "Alerta"
} else {
  estado <- "Sin alerta"
}

estado


# bucles tradicionales

# bucle for()

# creación de un vector
vector <- 1:10

# bucle que recorre el vector
for (i in 1:length(vector)) {
  
  print(paste0("Esta es la vuelta ", vector[i]))
  
}

# bucle while()

# inicializamos

i <- 1

while (i < 11) {
  
  print(paste0("Esta es la vuelta ", vector[i]))
  i <- i + 1
  
}

# map()

# datos ficticios

vigilancia <- tribble(
  ~evento,   ~casos, ~poblacion,  ~periodo, ~anio, ~provincia,
  # ---- Buenos Aires ----
  "dengue",     45,  17500000, "SE01", 2024, "Buenos Aires",
  "zika",        3,  17500000, "SE01", 2024, "Buenos Aires",
  "dengue",     52,  17500000, "SE02", 2024, "Buenos Aires",
  "zika",        5,  17500000, "SE02", 2024, "Buenos Aires",
  "dengue",     61,  17500000, "SE03", 2024, "Buenos Aires",
  "zika",        4,  17500000, "SE03", 2024, "Buenos Aires",
  "dengue",     78,  17500000, "SE04", 2024, "Buenos Aires",
  "zika",        6,  17500000, "SE04", 2024, "Buenos Aires",
  "dengue",     90,  17500000, "SE05", 2024, "Buenos Aires",
  "zika",        8,  17500000, "SE05", 2024, "Buenos Aires",
  # ---- Córdoba ----
  "dengue",     30,   3800000, "SE01", 2024, "Córdoba",
  "zika",        2,   3800000, "SE01", 2024, "Córdoba",
  "dengue",     35,   3800000, "SE02", 2024, "Córdoba",
  "zika",        4,   3800000, "SE02", 2024, "Córdoba",
  "dengue",     42,   3800000, "SE03", 2024, "Córdoba",
  "zika",        3,   3800000, "SE03", 2024, "Córdoba",
  "dengue",     55,   3800000, "SE04", 2024, "Córdoba",
  "zika",        5,   3800000, "SE04", 2024, "Córdoba",
  "dengue",     67,   3800000, "SE05", 2024, "Córdoba",
  "zika",        7,   3800000, "SE05", 2024, "Córdoba",
  # ---- Santa Fe ----
  "dengue",     25,   3500000, "SE01", 2024, "Santa Fe",
  "zika",        1,   3500000, "SE01", 2024, "Santa Fe",
  "dengue",     28,   3500000, "SE02", 2024, "Santa Fe",
  "zika",        3,   3500000, "SE02", 2024, "Santa Fe",
  "dengue",     33,   3500000, "SE03", 2024, "Santa Fe",
  "zika",        2,   3500000, "SE03", 2024, "Santa Fe",
  "dengue",     41,   3500000, "SE04", 2024, "Santa Fe",
  "zika",        4,   3500000, "SE04", 2024, "Santa Fe",
  "dengue",     50,   3500000, "SE05", 2024, "Santa Fe",
  "zika",        6,   3500000, "SE05", 2024, "Santa Fe",
  # ---- Mendoza ----
  "dengue",     10,   2000000, "SE01", 2024, "Mendoza",
  "zika",        0,   2000000, "SE01", 2024, "Mendoza",
  "dengue",     12,   2000000, "SE02", 2024, "Mendoza",
  "zika",        1,   2000000, "SE02", 2024, "Mendoza",
  "dengue",     15,   2000000, "SE03", 2024, "Mendoza",
  "zika",        2,   2000000, "SE03", 2024, "Mendoza",
  "dengue",     18,   2000000, "SE04", 2024, "Mendoza",
  "zika",        1,   2000000, "SE04", 2024, "Mendoza",
  "dengue",     22,   2000000, "SE05", 2024, "Mendoza",
  "zika",        3,   2000000, "SE05", 2024, "Mendoza",
  # ---- Salta ----
  "dengue",     20,   1400000, "SE01", 2024, "Salta",
  "zika",        5,   1400000, "SE01", 2024, "Salta",
  "dengue",     24,   1400000, "SE02", 2024, "Salta",
  "zika",        8,   1400000, "SE02", 2024, "Salta",
  "dengue",     29,   1400000, "SE03", 2024, "Salta",
  "zika",       10,   1400000, "SE03", 2024, "Salta",
  "dengue",     35,   1400000, "SE04", 2024, "Salta",
  "zika",       12,   1400000, "SE04", 2024, "Salta",
  "dengue",     40,   1400000, "SE05", 2024, "Salta",
  "zika",       15,   1400000, "SE05", 2024, "Salta"
)

glimpse(vigilancia)
  
vigilancia

# map()

# dividimos en listas
split(vigilancia$casos, vigilancia$provincia) 

# sumamos cada elemento de la lista
split(vigilancia$casos, vigilancia$provincia) |> 
  map(sum)

# map2()

# tasa por 1.000.000 para cada fila

map2_dbl(.x = vigilancia$casos,  
         .y = vigilancia$poblacion, 
         .f = ~ (.x / .y) * 1000000)

# recorremos dos variables y devolvemos un vector numérico

# pmap()

# resumen por fila usando paste() para unir

pmap_chr(
  .l = list(vigilancia$evento, vigilancia$provincia, vigilancia$periodo, vigilancia$casos),
  .f = function(e, p, pe, c) paste0(e, " | ", p, " | ", pe, " | ", c, " casos")) |> 
  head(8)

# recorremos 4 variables y devolvemos un vector caracter

# walk() y walk2()


mtcars # dataset de autos

?mtcars

list(mtcars) # transformamos en  lista de 1 componente

walk(list(mtcars), "mtcars.csv", write_csv2) # aplicamos write sobre el componente

iris # dataset de flores

list(mtcars, iris)   # transformamos en  lista de 2 componentes

walk2(list(mtcars, iris), c("mtcars.csv", "iris.csv"), write_csv2) # aplicamos write sobre los componentes

# creación de funciones

# alcance: local vs global

x <-  10  # vector global

mi_funcion <- function() {  

x <- 99  # vector local
cat("Dentro de la función, x =", x, "\n") 

}

mi_funcion()


cat("Fuera de la función, x =", x, "\n")

# si no la encuentra dentro (local) prevalece la global

y <- 5 # vector global

otra_funcion <- function() {
  cat("y vale:", y, "\n")  # R busca en el entorno local y luego global
}

otra_funcion()

# cambiamos nombre de vector

otra_funcion2 <- function() {
  cat("z vale:", z, "\n") # R busca en el entorno local y luego global
}

otra_funcion2()

# funciones vectoriales (trabajan sobre vectores o variables de df)


# función que calcula la edad en años
# toma fecha de nacimiento y una fecha posterior

calculo_edad <- function(fecha_nacimiento, fecha) {
  
  if (!"lubridate" %in% installed.packages()) {
    install.packages("lubridate")  
  }  
  
  require(lubridate) # suprime los mensajes
  
  if (is.character(fecha_nacimiento)) {
    fecha_nacimiento <- dmy(fecha_nacimiento)
  }  
  
  if (is.character(fecha)) {
    fecha <- dmy(fecha)
  }  
  
  interval(fecha_nacimiento, fecha)%/% dyears()
  
}

# cuerpo de la función
calculo_edad

# aplico sobre un vector

calculo_edad(fecha_nacimiento = "26/05/1973", fecha = today())

# aplico sobre datos

# leo datos sisa de ejemplo
datos <- read_csv2("ejemplo_sisa.csv")

glimpse(datos)

# calculo edad con la función
datos |> 
  select(FECHA_NACIMIENTO, FECHA_APERTURA) |> 
  mutate(edad = calculo_edad(FECHA_NACIMIENTO, FECHA_APERTURA)) 
  
# funciones de tablas de datos (entran y salen tablas de datos)

# función resumen

resumen <- function(datos, var) {
  
  if (!"dplyr" %in% installed.packages()) {
    install.packages("dplyr")  
  }  
  
  require(dplyr)
  
  datos |> summarise(
    min = min({{ var }}, na.rm = TRUE),
    media = mean({{ var }}, na.rm = TRUE),
    mediana = median({{ var }}, na.rm = TRUE),
    max = max({{ var }}, na.rm = TRUE),
    n = n(),
    n_NA = sum(is.na({{ var }}))
  )
}

# aplico sobre edad calculada

datos |> 
  select(FECHA_NACIMIENTO, FECHA_APERTURA) |> 
  mutate(edad = calculo_edad(FECHA_NACIMIENTO, FECHA_APERTURA)) |> 
  resumen(edad)

# Funciones gráficas (entran tablas de datos salen gráficos)

barras_ordenadas <- function(datos, var) {

if (!"tidyverse" %in% installed.packages()) {
  install.packages("tidyverse")  
}  

require(tidyverse)

  datos |> 
    mutate({{ var }} := fct_infreq({{ var }}))  |>
    ggplot(aes(x = {{ var }}, fill = {{ var }})) +
    geom_bar() +
    scale_fill_brewer(palette = "Dark2") +
    theme(legend.position = "bottom")
}

# aplico sobre variable categórica clasificacion resumen

datos |> 
  barras_ordenadas(var = CLASIF_RESUMEN)

# integro linea filtrando NA

datos |> 
  filter(!is.na(CLASIF_RESUMEN)) |> 
  barras_ordenadas(var = CLASIF_RESUMEN)


# validación con stop()

names(vigilancia)

col_requeridas <- c(
  "evento", "casos", "poblacion", "periodo", "anio", "provincia"
)

# uso de setdiff()

setdiff(col_requeridas, names(vigilancia))

# validar que las columnas necesarias se encuentren en los datos

validar_columnas <- function(datos, requeridas = col_requeridas) {
  
  faltan <- setdiff(requeridas, names(datos))
  
  if (length(faltan) > 0) {
    stop("Faltan columnas en los datos: ", paste(faltan, collapse = ", "),
         call. = F) # indica si el tipo de Error debe formar parte del mensaje 
  }
}


vigilancia |> validar_columnas()


col_requeridas2 <- c(
  "evento", "casos", "poblacion", "periodo", "anio", "provincia", "agregado"
)

setdiff(col_requeridas2, names(vigilancia))

vigilancia |> validar_columnas(requeridas = col_requeridas2)


# tryCatch(), stopifnot()

# tryCatch(
#   expr         código "normal" protegido y vigilado
#   error = f    atajo si hay error
#   warning = f  atajo si hay warning
#   ...          otros atajos (message, condition)
#   finally = g  corre SIEMPRE, valor descartado
# )


# donde:

# expr = Es el bloque de código que ejecutas "bajo protección" entre {}
# error = define un manejador (handler) como conditionMessage()  
# finally = Se ejecuta siempre (sea que la expresión haya tenido éxito o no)


tasa_incidencia <- function(datos, evento, provincia) {
  
  if (!requireNamespace("dplyr", quietly = TRUE)) {   # verifica la instalación del paquete
    install.packages("dplyr")                         # lo instala si no existe
  }
  
  
  tryCatch(
    {
      # --- Validaciones ---
      stopifnot(                    
        is.data.frame(datos),
        all(c("evento", "casos", "poblacion", "provincia") %in% names(datos)),
        is.character(evento), 
        length(evento) == 1,
        is.character(provincia), 
        length(provincia) == 1
      )                          # verifica si los datos son adecuados
      
      # --- Filtrar ---
      sub <- datos |> dplyr::filter(evento == {{ evento }}, 
                             provincia == {{ provincia }} )   # filtra según evento y provincia
      
      # para que el interprete entienda que evento es la variable del argumento y no
      # la variable cabecera del set de datos se encierra con {{ }}
      
      if (nrow(sub) == 0) {
        stop(sprintf(
          "No hay registros para evento = '%s' en provincia = '%s'",
          evento, provincia
        ))
      }
      
      # --- Calcular ---
      total_casos <- sum(sub$casos, na.rm = TRUE)
      poblacion   <- unique(sub$poblacion)
      
      if (length(poblacion) != 1) {
        stop("La población no es única para esa combinación evento/provincia")
      }
      
      tasa <- (total_casos / poblacion) * 100000    # calculo
      
      # --- Devolver resultado ---
      tibble(
        evento     = evento,
        provincia  = provincia,
        total_casos = total_casos,
        poblacion   = poblacion,
        tasa_100k   = round(tasa, 2)
      )
    },
    error = function(e) {
      message("Error en tasa_incidencia(): ", conditionMessage(e))  # maneja errores
      return(NULL)
    }, 
    finally = {                                                     # salida final
      message("Calculo finalizado.")
    }
  )
}

tasa_incidencia(vigilancia, "dengue", "Buenos Aires")  # funciona

tasa_incidencia(vigilancia, "dengue", "Tierra del Fuego") # error

tasa_incidencia(vigilancia, "chikungunya", "Córdoba") # error

tasa_incidencia(vigilancia, "chikungunya") # error

#-----------------

## vacío el entorno

## convoco en memoria las funciones

source("funciones_varias.R")

# se ejecuta el código y las tengo disponibles para usar
