# Paquetes ---------------------------------------------------------------------

library(quarto)
library(knitr)
library(stringi)
library(tidyverse)
library(sysfonts)
library(showtext)


# Utilidades generales ---------------------------------------------------------

# Formatea un número escalar con separador de miles "." y decimal ","
formatear <- function(x, digitos = 0) {
  if (is.na(x)) return("s/d")
  format(round(x, digitos), big.mark = ".", decimal.mark = ",",
         nsmall = digitos, trim = TRUE)
}

# Arma un nombre de archivo seguro a partir de una jurisdicción:
# "Córdoba" -> "boletin_cordoba.html"
nombre_archivo <- function(jurisdiccion, prefijo = "boletin", ext = "html") {
  slug <- jurisdiccion |>
    stri_trans_general("Latin-ASCII") |>
    tolower() |>
    gsub(pattern = "[^a-z0-9]+", replacement = "_")
  paste0(prefijo, "_", slug, ".", ext)
}
