# Limpieza y recodificación ----------------------------------------------------

clasificar_grupo_etario <- function(edad) {
  cut(edad,
      breaks = c(-Inf, 4, 14, 39, 59, 79, Inf),
      labels = c("0-4", "5-14", "15-39", "40-59", "60-79", "80+"))
}

# Fecha de inicio (domingo) de la semana epidemiológica
inicio_semana_epi <- function(fecha) {
  floor_date(fecha, unit = "week", week_start = 7)
}

limpiar_casos <- function(datos) {
  datos |>
    filter(clasificacion_resumen == "Confirmado") |>
    mutate(
      edad_anios    = if_else(edad_anios_meses %in% "Meses", 0L, edad),
      grupo_etario  = clasificar_grupo_etario(edad_anios),
      sexo          = if_else(sexo %in% c("F", "M"), sexo, NA_character_),
      fallecido     = fallecido %in% "SI",
      internado     = !is.na(fecha_internacion),
      semana_inicio = inicio_semana_epi(fecha_apertura)
    ) |>
    select(
      id_evento_caso, sexo, edad_anios, grupo_etario,
      provincia = residencia_provincia_nombre,
      fecha_apertura, semana_inicio, internado, fallecido
    )
}
