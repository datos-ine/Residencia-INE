# Funciones de análisis: devuelven datos, no gráficos ni texto de informe -------

validar_jurisdiccion <- function(casos, jurisdiccion) {
  validas <- c("Todas", sort(unique(casos$provincia)))
  if (!jurisdiccion %in% validas) {
    stop("Jurisdicción no válida: '", jurisdiccion, "'. Opciones: ",
         paste(validas, collapse = ", "), call. = FALSE)
  }
  invisible(TRUE)
}

filtrar_casos <- function(casos, jurisdiccion = "Todas", desde, hasta,
                          grupo = "todos") {
  validar_jurisdiccion(casos, jurisdiccion)
  if (!grupo %in% c("todos", levels(casos$grupo_etario))) {
    stop("Grupo etario no válido: '", grupo, "'. Opciones: todos, ",
         paste(levels(casos$grupo_etario), collapse = ", "), call. = FALSE)
  }

  res <- filter(casos, fecha_apertura >= desde, fecha_apertura <= hasta)
  if (jurisdiccion != "Todas") res <- filter(res, provincia == jurisdiccion)
  if (grupo != "todos")        res <- filter(res, grupo_etario == grupo)
  res
}

casos_por_semana <- function(casos) {
  if (nrow(casos) == 0) {
    return(tibble(semana_inicio = as.Date(character()), casos = integer()))
  }
  casos |>
    count(semana_inicio, name = "casos") |>
    complete(
      semana_inicio = seq(min(semana_inicio), max(semana_inicio), by = "week"),
      fill = list(casos = 0L)
    )
}

semana_pico <- function(semanal) {
  slice_max(semanal, casos, n = 1, with_ties = FALSE)
}

resumen_jurisdiccion <- function(casos, poblacion, jurisdiccion, grupo = "todos") {
  pob <- if (jurisdiccion == "Todas") {
    sum(poblacion$poblacion)
  } else {
    poblacion$poblacion[poblacion$provincia == jurisdiccion]
  }
  if (length(pob) != 1) stop("No hay denominador para: ", jurisdiccion, call. = FALSE)

  n_casos <- nrow(casos)
  n_fall  <- sum(casos$fallecido)

  tibble(
    casos      = n_casos,
    fallecidos = n_fall,
    letalidad  = if (n_casos > 0) 100 * n_fall / n_casos else NA_real_,
    poblacion  = pob,
    # La tasa solo tiene sentido si numerador y denominador son la misma población
    tasa       = if (grupo == "todos") 1e5 * n_casos / pob else NA_real_
  )
}

tabla_resumen <- function(resumen) {
  tibble(
    Indicador = c("Casos confirmados", "Fallecidos", "Letalidad (%)",
                  "Población", "Tasa cada 100.000 hab."),
    Valor = c(formatear(resumen$casos), formatear(resumen$fallecidos),
              formatear(resumen$letalidad, 1), formatear(resumen$poblacion),
              formatear(resumen$tasa, 1))
  )
}

texto_resumen <- function(resumen, semanal, jurisdiccion, desde, hasta) {
  f <- function(x) format(x, "%d/%m/%Y")
  if (resumen$casos == 0) {
    return(paste0("No se registraron casos confirmados en ", jurisdiccion,
                  " entre el ", f(desde), " y el ", f(hasta), "."))
  }
  pico <- semana_pico(semanal)
  paste0("En ", jurisdiccion, " se notificaron ", formatear(resumen$casos),
         " casos confirmados entre el ", f(desde), " y el ", f(hasta),
         ", con un máximo de ", formatear(pico$casos),
         " casos en la semana que inicia el ", f(pico$semana_inicio), ".")
}
