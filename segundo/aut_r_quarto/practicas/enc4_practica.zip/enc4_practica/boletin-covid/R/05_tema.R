# Identidad visual para gráficos: debe dialogar con scss/paleta-*.scss ----------

paleta_boletin <- c(
  principal = "#1b6ca8",   # = $primary (modo claro)
  acento    = "#d95f0e",   # = $acento (modo claro)
  neutro    = "#7f8c8d"    # texto de ejes: legible sobre fondo claro y oscuro
)

# Intenta cargar una fuente de Google para los gráficos (opcional).
# Si no hay internet o faltan paquetes, usa la fuente por defecto sin fallar.
configurar_fuente <- function(familia = "Source Sans 3") {
  usada <- tryCatch({
    if (!requireNamespace("showtext", quietly = TRUE) ||
        !requireNamespace("sysfonts", quietly = TRUE)) stop("sin showtext")
    font_add_google(familia, familia)
    showtext_auto()
    familia
  }, error = function(e) "sans")
  options(boletin.fuente = usada)
  invisible(usada)
}

# Tema ggplot2 del proyecto. Fondo transparente para que funcione con ambos modos.
theme_boletin <- function(base_size = 12) {
  gris <- paleta_boletin[["neutro"]]
  theme_minimal(base_size = base_size,
                         base_family = getOption("boletin.fuente", "sans")) +
    theme(
      plot.background  = element_rect(fill = NA, colour = NA),
      panel.background = element_rect(fill = NA, colour = NA),
      text             = element_text(colour = gris),
      axis.text        = element_text(colour = gris),
      panel.grid.major = element_line(colour = "#7f8c8d33"),
      panel.grid.minor = element_blank(),
      legend.position  = "bottom"
    )
}
