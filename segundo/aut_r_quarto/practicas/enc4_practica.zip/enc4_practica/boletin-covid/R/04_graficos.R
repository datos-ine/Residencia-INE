# Funciones gráficas: reciben datos ya procesados, devuelven un ggplot ----------
# El aspecto (colores, fuente) viene de R/05_tema.R, no se define acá.

grafico_curva_epi <- function(semanal) {
  ggplot(semanal, aes(semana_inicio, casos)) +
    geom_col(fill = paleta_boletin[["principal"]], width = 6) +
    scale_x_date(date_breaks = "2 months", date_labels = "%b %Y") +
    labs(x = "Semana (fecha de inicio)", y = "Casos confirmados") +
    theme_boletin()
}

grafico_piramide <- function(casos) {
  datos <- casos |>
    filter(!is.na(sexo), !is.na(grupo_etario)) |>
    count(grupo_etario, sexo) |>
    mutate(n = if_else(sexo == "M", -n, n))

  ggplot(datos, aes(n, grupo_etario, fill = sexo)) +
    geom_col() +
    scale_x_continuous(labels = abs) +
    scale_fill_manual(
      values = c(F = paleta_boletin[["acento"]], M = paleta_boletin[["principal"]]),
      labels = c(F = "Femenino", M = "Masculino")
    ) +
    labs(x = "Casos confirmados", y = "Grupo etario", fill = NULL) +
    theme_boletin()
}
