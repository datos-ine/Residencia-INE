library(tidyverse)

datos <- read_csv2("data/raw/sisa_covid_simulado.csv")

conteo_colores <-  length(unique(datos$residencia_provincia_nombre))

conteo_colores  

## Colores con RColorBrewer

library(RColorBrewer)

# 24 colores a crear por la nueva paleta

nueva_paleta <- colorRampPalette(brewer.pal(24, "Set3"))

for (i in 1:24) {
  cat("La nueva paleta tiene los colores: " , nueva_paleta(n = i), "\n")
}

## Colores con cols4all

# install.packages("colorblindcheck")

library(cols4all)

c4a_gui()

c4a_plot("powerbi.temperature", nrows = 1)

c4a(palette = "powerbi.temperature")

c4a_info(palette = "powerbi.temperature")

c4a_citation(name = "powerbi")

datos_paleta <- c4a_data(
     x = list(mi_atardecer = c("#2b5c8f", "#d95f02", "#e6ab02", "#7570b3")),
     type = "cat",
     series = "mis_paletas")

c4a_load(datos_paleta)

c4a("mis_paletas.mi_atardecer")

library(datos)

pinguinos |> 
  ggplot(aes(x = largo_pico_mm, y = alto_pico_mm, color = especie)) +
  geom_point(size = 2) +
  scale_color_discrete_c4a_cat("carto.safe") +
  theme_light()

pinguinos |> 
  ggplot(aes(x = largo_pico_mm, y = alto_pico_mm, color = masa_corporal_g)) +
    geom_point(size = 2) +
    scale_color_continuous_c4a_div("wes.zissou1", mid = mean(pinguinos$masa_corporal_g, na.rm = TRUE)) +
    theme_light()



## personalización de theme

# La función theme() permite personalizar las partes del gráfico, por ejemplo:

## creamos un tema estético general para nuestros gráficos

## Fuentes

# Para usar una fuente personalizada, es necesario instalar los archivos 
# de fuente .ttf o .otf en la máquina local. Aca estamos usando los conocidos 
# tipos de letra Roboto que están disponibles a través de GoogleFonts:

# https://fonts.google.com/specimen/Roboto?query=roboto

# Deberiamos descargar e intalar Roboto fonts en nuestra PC antes de proseguir


## configuramos el tema personalizado

mi_tema <- theme_void() + theme(
  plot.title = element_text(family = "Roboto", face = "bold", size = 18), 
  plot.caption = element_text(family = "Roboto",face = "italic", size = 10, color = "gray30", hjust = 0), 
  axis.text.x = element_text(family = "Roboto",color = "black", size = 12, 
                             margin = margin(t = 6)),
  axis.text.y = element_text(family = "Roboto",color = "black", size = 12, hjust = 1, 
                             margin = margin(r = 6)),
  axis.line.x = element_line(color = "black", linewidth = 1),
  panel.grid.major.y = element_line(color = "grey90", linewidth = 0.6),
  plot.background = element_rect(fill = "white", color = "white"),
  plot.margin = margin(20,20,20,20)
)

pinguinos |> 
  ggplot(aes(x = largo_pico_mm, 
             y = alto_pico_mm, 
             color = especie)) +
  geom_point(size = 2) +
  scale_color_discrete_c4a_cat("carto.safe") +
  labs(title = "Dispersión entre largo y alto de pico agrupado por especie",
       caption = "Ejemplo de tema personal") +
  mi_tema
