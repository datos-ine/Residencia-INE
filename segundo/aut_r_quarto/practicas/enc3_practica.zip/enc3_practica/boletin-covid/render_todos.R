# Genera un informe por jurisdicción a partir de un solo boletin.qmd -----------
# Ejecutar desde la raíz del proyecto:  source("render_todos.R")

library(tidyverse)
library(quarto)

# ejecutar los source de los 5 scripts de la carpeta R

walk(list.files("R", pattern = "\\.R$", full.names = TRUE), source)

# lee los datos sisa_covid_simulado.csv y los limpia

datos <- leer_sisa("data/raw/sisa_covid_simulado.csv") |> limpiar_casos()

jurisdicciones <- sort(unique(datos$provincia))  # produce vector de provincias

# --- Una jurisdicción: la misma plantilla, parámetros distintos ---------------
renderizar_boletin <- function(jurisdiccion,
                               desde = "2022-01-01",
                               hasta = "2022-12-31",
                               grupo = "todos") {
  quarto_render(
    input = "boletin.qmd",
    output_file = nombre_archivo(jurisdiccion),
    execute_params = list(
      jurisdiccion = jurisdiccion,
      fecha_desde  = desde,
      fecha_hasta  = hasta,
      grupo_etario = grupo
    )
  )
}

# --- Todas las jurisdicciones -------------------------------------------------
walk(jurisdicciones, renderizar_boletin)

# Variantes para explorar en clase:
# renderizar_boletin("Córdoba", desde = "2022-01-01", hasta = "2022-03-31")
# renderizar_boletin("Todas")
# renderizar_boletin("Santa Fe", grupo = "60-79")
