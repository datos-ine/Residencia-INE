# Funciones gráficas: reciben datos ya procesados, devuelven un ggplot ----------

grafico_curva_epi <- function(semanal) {
  ggplot(semanal, aes(semana_inicio, casos)) +
    geom_col(fill = "#2c7fb8", width = 6) +
    scale_x_date(date_breaks = "2 months", date_labels = "%b %Y") +
    labs(x = "Semana (fecha de inicio)", y = "Casos confirmados") +
    theme_minimal(base_size = 12)
}

grafico_piramide <- function(casos) {
  datos <- casos |>
    filter(!is.na(sexo), !is.na(grupo_etario)) |>
    count(grupo_etario, sexo) |>
    mutate(n = if_else(sexo == "M", -n, n))

  ggplot(datos, aes(n, grupo_etario, fill = sexo)) +
    geom_col() +
    scale_x_continuous(labels = abs) +
    scale_fill_manual(values = c(F = "#d95f0e", M = "#2c7fb8"),
                               labels = c(F = "Femenino", M = "Masculino")) +
    labs(x = "Casos confirmados", y = "Grupo etario", fill = NULL) +
    theme_minimal(base_size = 12) +
    theme(legend.position = "bottom")
}
