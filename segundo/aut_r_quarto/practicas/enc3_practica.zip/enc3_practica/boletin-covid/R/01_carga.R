# Carga y validación de datos --------------------------------------------------

COLUMNAS_REQUERIDAS <- c(
  "id_evento_caso", "sexo", "edad", "edad_anios_meses",
  "residencia_provincia_nombre", "fecha_apertura", "fecha_internacion",
  "cuidado_intensivo", "fallecido", "fecha_fallecimiento",
  "clasificacion_resumen"
)

validar_columnas <- function(datos, requeridas = COLUMNAS_REQUERIDAS) {
  faltan <- setdiff(requeridas, names(datos))
  if (length(faltan) > 0) {
    stop("Faltan columnas en los datos: ", paste(faltan, collapse = ", "),
         call. = FALSE)
  }
  invisible(datos)
}

leer_sisa <- function(ruta) {
  if (!file.exists(ruta)) stop("No se encuentra el archivo: ", ruta, call. = FALSE)
  datos <- read_csv2(
    ruta,
    col_types = cols(
      id_evento_caso      = col_integer(),
      edad                = col_integer(),
      fecha_apertura      = col_date(),
      fecha_internacion   = col_date(),
      fecha_fallecimiento = col_date(),
      .default            = col_character()
    )
  )
  validar_columnas(datos)
  datos
}
