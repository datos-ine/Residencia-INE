library(tidyverse)

datos_covid <- read_csv2("SISA_covid.csv")


## vemos estructura de la tabla

glimpse(datos_covid)

# 11 variables
# 6.687.347 observaciones

### usamos select()

datos_covid  # tabla completa

# salidas a consola

datos_covid |> select(fecha_inicio_sintomas)  # solo fecha inicio de síntomas

datos_covid |> select(-fecha_inicio_sintomas) # todas menos fecha inicio de síntomas

datos_covid |> select(sexo, edad) # solo sexo y edad

datos_covid |> select(-c(sexo, edad)) # todas menos sexo y edad

datos_covid |> select(-sexo, -edad) # todas menos sexo y edad

datos_covid |> select(1,2,3) # usando posiciones numéricas (las primeras tres variables)

datos_covid |> select(1,2,11) # posiciones numéricas 1,2 y 11

datos_covid |> select(1:3) # rango de variable 1 a 3

datos_covid |> select(sexo:residencia_pais_nombre) # rango con nombres de variable

datos_covid |> select(starts_with("resi")) # variables comienzan con "resi"

datos_covid |> select(ends_with("apertura")) # variables finalizan con "apertura"

## salida a nueva tabla

datos_resi <- datos_covid |> select(starts_with("resi"))

datos_resi

rm(datos_resi) # eliminamos la tabla datos_resi de la memoria con rm()

## salida a visualización en tabla

datos_covid |> select(starts_with("resi")) |> View()


##################

# seleccione de la tabla datos_covid las variables que comienzan con "fecha"



# seleccione de la tabla datos_covid las variables que finalicen con "nombre"



######

# filter()

# selecciones simples

datos_covid |> filter(sexo == "F") # filtramos solo a las mujeres

datos_covid |> filter(edad > 64) # filtramos observaciones mayores a 64 años

datos_covid |> filter(edad >= 64) # filtramos observaciones mayores o iguales a 64 años

datos_covid |> filter(residencia_pais_nombre != "Argentina") # filtramos observaciones que no residan en Argentina

# selección  teniendo en cuenta los valores especiales NA

datos_covid |> filter(is.na(fecha_inicio_sintomas)) # filtramos observaciones con NA en fecha_inicio_sintomas


# selecciones combinadas

datos_covid |> filter(residencia_provincia_nombre %in% c("Jujuy", "Salta")) # filtramos observaciones de Jujuy o Salta

datos_covid |> filter(between(sepi_apertura, 30, 40)) # filtramos observaciones con sepi_apertura entre 30 y 40 (se incluyen los extremos)

datos_covid |> filter(edad >= 64 & sexo == "F") # filtramos observaciones de mujeres mayores o iguales a 64 años                      

datos_covid |> filter(edad >= 64, sexo == "F") # filtramos observaciones de mujeres mayores o iguales a 64 años   

datos_covid |> filter(residencia_provincia_nombre == "Jujuy" | residencia_provincia_nombre == "Salta")  # filtramos observaciones de Jujuy o Salta


datos_covid |> filter(fecha_inicio_sintomas > "2020-12-01") # filtramos observaciones con inicio de sintomas mayores al 1-12-2020   

## los tipos de datos fecha (Date) tienen las misma propiedades que las variables numéricas

##################

# filtre de la tabla datos_covid las observaciones que residan en el departamento de Pergamino y sean menores de 10 años



# filtre de la tabla datos_covid las observaciones de hombres que hayan fallecido



##################

# Resumimos las edades mediante una media

datos_covid |> 
  summarise(media_edad = mean(edad))

## se acuerdan que dijimos que los valores especiales NA (datos no disponible) 
## eran "contagiosos". 

## si el resultado de un resumen nos devuelve NA es porque al menos una observación
## de la variable en cuestión (edad en este caso) tiene valor NA

datos_covid |> 
  filter(is.na(edad)) |> count(edad)  # hay 3785 edades como NA

## como hacemos para que las funciones eviten estos valores?

## usando el argumento na.rm = TRUE dentro de mean()

datos_covid |> 
  summarise(media_edad = mean(edad, na.rm = TRUE))

## podemos calcular varios resúmenes dentro del mismo summarise

datos_covid |> 
  summarise(media_edad = mean(edad, na.rm = TRUE),
            mediana_edad = median(edad, na.rm = TRUE))

# podemos integrar otras funciones conocidas, como filter()

datos_covid |> 
  filter(residencia_provincia_nombre == "Catamarca") |> 
  summarise(media_edad = mean(edad, na.rm = TRUE),
            mediana_edad = median(edad, na.rm = TRUE))

# resumen de media y mediana de la edad de los casos notificados residentes 
# de la provincia de Catamarca

###########

## veamos algunas otras funciones de resumen mencionadas en las diapositivas

datos_covid |> 
  summarise(min_edad = min(edad, na.rm = TRUE),
            max_edad = max(edad, na.rm = TRUE),
            var_edad = var(edad, na.rm = TRUE),
            sd_edad = sd(edad, na.rm = TRUE),
            IQR_edad = IQR(edad, na.rm = TRUE))

## que pasa con el valor máximo de edad? Parece que se trata de un error

# veamos los valores máximos cercanos ordenando la variable

datos_covid |> select(edad) |> arrange(desc(edad)) 

# hay 5 observaciones con edades imposibles

# podriamos arreglar esto usando filter

datos_covid |> 
  filter(edad < 132) |> 
  summarise(min_edad = min(edad, na.rm = TRUE),
            max_edad = max(edad, na.rm = TRUE),
            var_edad = var(edad, na.rm = TRUE),
            sd_edad = sd(edad, na.rm = TRUE),
            IQR_edad = IQR(edad, na.rm = TRUE))

## con quantile se puede mostrar distintos valores de posición de la distribución
## de edad. Por ejemplo el primer y tercer cuartil 


datos_covid |>   
  summarise(cuartil = quantile(edad, 
                               na.rm = TRUE, 
                               prob = c(0.25, 0.75)))

## percentilos incluidos minimo y maximo

datos_covid |>   
  filter(edad < 132) |>
  summarise(percentil = quantile(edad, 
                                 na.rm = TRUE, 
                                 prob = seq(from = 0, to = 1, by = 0.1)))

### otras funciones resumen básicas son los conteos

datos_covid |>   
  summarise(cantidad = n())

## cuando se resume una variable suele acompañarse con el conteo de observaciones
## para conocer el tamaño de la población/muestra con la que estamos trabajando

## n_distinc() es útil para variables categóricas o cuantitativas discretas

datos_covid |>   
  summarise(cantidad = n_distinct(sepi_apertura))  # 53 semanas epidemiológicas

datos_covid |>   
  summarise(cantidad = n_distinct(sexo)) # 3 categorías diferentes de sexo

#### agrupamientos

## la función group_by() agrupa por los valores distintos de la variable que usemos
## como argumento. Hay que pensarla como la variable o variables que deseamos que
## estratifiquen el resumen aplicado por summarise()

## si usamos group_by() solo obtenemos

datos_covid |> group_by(sexo)

## noten que en la salida de la consola el encabezado dice Groups: sexo [3],
## mientras que si llamamos a la tabla datos_covid solamente eso no aparece

datos_covid

## pero por más que nos muestre que la tabla se encuentra agrupada por sexo en
## sus tres categorías en definitiva no nos devuelve ningun resultado útil

## en cambio si luego aplicamos summarise() nos va a calcular el resumen pedido
## para cada uno de los grupos construidos

datos_covid |> 
  group_by(sexo) |> 
  summarise(media_edad = mean(edad, na.rm = T))

# este resultado sería media edad estratificado por sexo

# también es interesante agregar el conteo a este resultado para conocer 
# el n de cada grupo

datos_covid |> 
  group_by(sexo) |> 
  summarise(media_edad = mean(edad, na.rm = T),
            cantidad = n())

# podemos anidar variables de agrupamiento 

datos_covid |> 
  group_by(clasificacion_resumen, sexo) |> 
  summarise(media_edad = mean(edad, na.rm = T),
            cantidad = n())

## ahora agregando la provincia de residencia 

datos_covid |> 
  group_by(residencia_provincia_nombre, clasificacion_resumen, sexo) |> 
  summarise(media_edad = mean(edad, na.rm = T),
            cantidad = n()) 

## igual al anterior pero sin group_by()

datos_covid |> 
  summarise(media_edad = mean(edad, na.rm = T),
            cantidad = n(),
            .by = c(residencia_provincia_nombre, clasificacion_resumen, sexo))

######

## Con todo lo visto hasta ahora escriba el código para obtener los siguientes
## resultados:

# A)
# La media y el desvío estandar de la edad de los fallecidos de CABA
# estratificado por sexo



# B)
# La edad mínima (ordenada de menor a mayor) de los casos confirmados de la 
# provincia de Chaco estratificado por departamento de residencia y sexo 
# (muestre en el visualizador)




# C)
# La fecha menor de apertura de los casos confirmados estratificados por provincia
# y ordenados de la fecha mayor a la menor.





######

## Ordenamiento

# podriamos también construir una tabla con los confirmados por provincia
# de residencia

conf_prov <- datos_covid |> 
  filter(clasificacion_resumen == "Confirmado") |> 
  count(residencia_provincia_nombre, name = "confirmados")

# una de las funciones de ranking es min_rank() y también se aplica con mutate()

conf_prov |> 
  mutate(ranking = min_rank(confirmados)) 

# agregamos desc() para ranking descendente

conf_prov |> 
  mutate(ranking = min_rank(desc(confirmados))) 

## ordenamos la salida para ver mejor los valores de la variable construida

conf_prov |> 
  mutate(ranking = min_rank(desc(confirmados))) |> 
  arrange(ranking)

## if_else()

# tomemos una variable para ejemplificar el uso de if_else()

# veamos cuantas categorías tiene clasificacion_resumen

datos_covid |> 
  distinct(clasificacion_resumen)

## son 4 categorías. Supongamos que deseamos unificar dos de ellas 
# (Sospechoso y Sin Clasificar) en una sola categoría denominada "Sin resultado"

datos_covid |>  
  mutate(nueva_clasificacion = if_else(clasificacion_resumen %in% c("Sospechoso","Sin Clasificar"),"Sin resultado", clasificacion_resumen)) |> 
  count(nueva_clasificacion)


## case_when()

# Una de las tareas habituales en el manejo de la variable edad es construir
# grupos etarios para categorizar la variable original cuantitativa

# por ejemplo necesitamos construir grupos de edad con los siguientes intervalos
# de clase:

# 0 a 17 años
# 18 a 24 años
# 25 a 34 años
# 35 a 49 años
# 50 a 64 años
# 65 y más años

## antes vamos a recortar un poco la tabla de datos para trabajar con menor
## cantidad de filas y evitar demora en la carga de trabajo

covid_SL <- datos_covid |> 
  filter(residencia_provincia_nombre == "San Luis")



covid_SL |> 
  mutate(grupo_edad = case_when(
    edad < 18 ~ "1. 0 a 17 años",
    edad > 17 & edad < 25 ~ "2. 18 a 24 años",
    edad > 24 & edad < 35 ~ "3. 25 a 34 años",
    edad > 34 & edad < 50 ~ "4. 35 a 49 años",
    edad > 49 & edad < 65 ~ "5. 50 a 64 años",
    edad > 64 ~ "6. 65 y más años"
  )
  ) |> 
  count(grupo_edad)


# igual usando between()

covid_SL <- covid_SL |> 
  mutate(grupo_edad = case_when(
    edad < 18 ~ "1. 0 a 17 años",
    between(edad, 18, 24) ~ "2. 18 a 24 años",
    between(edad, 25, 34) ~ "3. 25 a 34 años",
    between(edad, 35, 49) ~ "4. 35 a 49 años",
    between(edad, 50, 64) ~ "5. 50 a 64 años",
    edad > 64 ~ "6. 65 y más años"
  )
  ) 





