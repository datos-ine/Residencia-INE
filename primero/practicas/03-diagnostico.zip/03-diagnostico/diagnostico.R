# Diagnóstico y depuración de datos

# Activamos los paquetes necesarios.

library(tidyverse)
library(skimr)
library(dlookr)
library(naniar)
library(janitor)

# leemos datos

datos <- read_csv2("defunciones_2022_Santa_Fe.csv")

# exploramos datos

glimpse(datos)

# ¿Cuántas categorías distintas tiene la variable PROVRES? 
# ¿Están todas las variables del dataframe completas, es decir, sin valores NA?

skim(datos) 
  
# Diagnostique el dataframe y ubique la o las variable/s que tengan valores NA 
# mediante código para obtener el conteo y porcentaje de valores “missing”.

diagnose(datos) |> 
  select(!starts_with("unique")) |> 
  filter(missing_count > 0) 

# Utilizando la función diagnose_category() de dlookr muestre una tabla de
# frecuencias (ordenada de mayor a menor) con las categorías (levels) que más se
# repiten considerando todas las variables de tipo carácter (18 variables). Tenga
# en cuenta que en la columna freq de la tabla de diagnose_category() está el
# conteo de la etiqueta levels en cada una de las variables. 
# ¿Cuál es la etiqueta que más se repite sumadas las 18 variables de tipo carácter?

diagnose_category(datos) |> 
  count(levels, sort = T, wt = freq)

# Genere y almacene bajo el nombre de x_var, un vector que almacene los
# nombres de las variables que tengan al menos 1 categoría igual a la hallada en el
# punto anterior. Utilice la función diagnose_category() de dlookr para hacer el
# trabajo.

x_var <- diagnose_category(datos) |> 
  filter(levels == "NULL") |> 
  pull(variables)

x_var

# Realice un diagnóstico numérico con dlookr. ¿Cuántas variables de tipo
# numérico aparecen? ¿Todas son realmente variables cuantitativas? ¿Cuál o
# cuáles efectivamente lo son?

datos|> 
  diagnose_numeric()

# Diagnostique los valores outlier de la o las variables cuantitativas 
# verdaderas del dataframe obteniendo, mediante código, la diferencia entre 
# la media incluyendo todas las observaciones y la media sin contar los 
# valores outlier.

datos|> 
  diagnose_outlier(EDAD) |> 
  mutate(dif = with_mean - without_mean)

# Diagnostique los valores outlier de la o las variables cuantitativas 
# verdaderas del dataframe de forma gráfica. ¿Qué observa en el boxplot e 
# histograma incluyendo los outlier? ¿Qué puede explicar ese comportamiento?

datos |> 
  plot_outlier(EDAD) 

summary(datos$EDAD)

# Repare la situación anterior en el dataframe y vuelva a diagnosticar analítica y
# gráficamente los outlier.

datos <- datos |> 
  replace_with_na(replace = list(EDAD = 999))

datos|> 
  diagnose_outlier(EDAD) |> 
  mutate(dif = with_mean - without_mean)

datos |> 
  plot_outlier(EDAD) 

# teniendo en cuenta la unidad de la edad

datos|> 
  filter(UNIEDAD == 1) |> 
  diagnose_outlier(EDAD) |> 
  mutate(dif = with_mean - without_mean)

datos |> 
  filter(UNIEDAD == 1) |> 
  plot_outlier(EDAD) 

# Detecte si existen observaciones duplicadas completas en el dataframe, 
# es decir que tengan todas las variables iguales en sus observaciones. 
# ¿Cuántas hay?

datos |> 
  get_dupes(everything())

# Elimine las observaciones duplicadas y guarde el resultado con el mismo nombre
# agregando el sufijo _clean.

datos_clean <- datos |> 
  distinct(.keep_all = T)

dim(datos)

dim(datos_clean)

