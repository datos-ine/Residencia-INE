## Datos relacionales

## Activamos tidyverse

library(tidyverse)

## Creamos dos tablas pequeñas para la práctica

casos <- tribble(
  ~DNI,   ~edad, ~sexo, 
  23654738, 46,     "Mujer",
  12432098, 60,     "Varon",
  20987302, 50,     "Varon",
  17235092, 53,     "Mujer",
  5425810,  71,     "Mujer"
)

muertes <- tribble(
  ~DNI,   ~fecha,  
  23654738, "12/12/2018",    
  12432098, "03/10/2018",    
  20987400, "24/05/2018",    
  17235092, "08/02/2018",    
  5425990,  "16/03/2018" 
)

## Mutating joins (Uniones de transformación)

## En todos los casos asume a la variable DNI (única que se encuentra en las
## dos tablas) como clave

inner_join(casos,muertes) # unión interior

# uniones exteriores

left_join(casos,muertes) # agrega NA en variables de muertes

right_join(casos,muertes) # agrega NA en variables de casos

full_join(casos,muertes) # agrega NA en todas las variables


## Filtering joins (Uniones de filtro)

semi_join(casos,muertes) # Mantiene las observaciones donde DNI coincide

anti_join(casos,muertes) # Descarta las observaciones donde DNI coincide


## Que sucede cuando los nombres de las claves son distintas?

## modificamos la tabla muertes cambiando el nombre de la variable clave

muertes <- tribble(
  ~Documento,       ~fecha,  
  23654738, "12/12/2018",    
  12432098, "03/10/2018",    
  20987400, "24/05/2018",    
  17235092, "08/02/2018",    
  5425990,  "16/03/2018" 
)

## si intentamos la unión con la forma anterior, que nos devuelve?
inner_join(casos, muertes)

## Informa de un error porque las dos tablas no tienen al menos una variable 
## común

## Por lo que debemos indicarle en el argumento by el nombre de las variables 
## claves de cada tabla

inner_join(casos, muertes, 
           by = join_by("DNI" == "Documento"))

## la forma es join_by("nombre clave tabla1" == "nombre clave tabla2")

#################

## Ejercicio practico con datos de vuelos

library(datos)  # paquete que contiene los dataset

## vemos estructuras

# Tabla vuelos
glimpse(vuelos)

# Tabla aerolineas
glimpse(aerolineas)

# Tabla aeropuertos
glimpse(aeropuertos)

# Tabla aviones
glimpse(aviones)

# Tabla clima
glimpse(clima)


## Claves

## Clave primaria simple (1 variable)

aviones |>  count(codigo_cola, sort = T) # clave única

aviones |>  count(tipo, sort = T) # no es clave

aviones |>  count(codigo_cola) |> 
  filter(n > 1)     # otra forma de verificar

## Clave foránea (de la misma variable en otra tabla)

vuelos |>  count(codigo_cola, sort = T) # se une con aviones muchos a uno

## es decir que codigo_cola es clave primaria de aviones porque identifica de
## forma única cada observación
## y es clave foránea de vuelos porque únicamente identifica una observación 
## en la tabla aviones

## Igual podemos adelantarnos a decir que esos valores faltantes van a ser un 
## problema!!


## Clave primaria compuesta (más de 1 variable)

vuelos |>  count(origen, anio, mes, dia, horario_salida, vuelo) |>  
  filter(n > 1)

## Loa valores faltantes rompen las claves primarias, lo mismo errores de carga.

## Clave subrogada

## A veces necesitamos crear una variable como clave única en tablas donde no
## existen. Se llaman clavas subrogadas y se pueden generar en base al número
## de fila

vuelos <- vuelos |> 
  mutate(clave = row_number())

## row_number() pertenece a dplyr y agrega a una variable el número de fila



## Tablas "auxiliares"

## Algunas tablas contienen solo información auxiliar de modo que generalmente
## tenemos dos variables: una con un código y otra con la descripción del código

## por ejemplo: aerolíneas

aerolineas

## Las tablas donde existe la variable aerolinea guardan el código que se asocia
## con la tabla aerolineas

## por ejemplo: vuelos

## Si quiseramos informar sobre las aerolineas que operaron el 1 de enero de 2013
## podríamos hacer:

vuelos |> filter(anio == 2013, mes == 1, dia == 1) |> 
  count(aerolinea)

## Para que la tabla sea presentable  necesitaríamos los nombres
## de las aerolíneas

vuelos |> filter(anio == 2013, mes == 1, dia == 1) |> 
  count(aerolinea) |> left_join(aerolineas)

################

## Ahora les propongo que respondamos algunas preguntas:

## De qué período son los vuelos de la tabla vuelos?

vuelos |> summarise(min_anio = min(anio),
                     min_mes = min(mes),
                     min_dia = min(dia),
                     max_anio = max(anio),
                     max_mes = max(mes),
                     max_dia = max(dia))

## Cómo se llaman los aeropuertos desde donde despegan los vuelos de 
## la tabla vuelos?


vuelos |> distinct(origen) |> 
  inner_join(select(aeropuertos, codigo_aeropuerto, nombre), 
                    by = join_by("origen" == "codigo_aeropuerto"))

## En cuál de estos aeropuertos despegaron mayor cantidad vuelos cada mes 
## del 2013?

vuelos |> count(mes, origen) |> 
  inner_join(select(aeropuertos, codigo_aeropuerto, nombre), 
             by = join_by("origen" == "codigo_aeropuerto")) |> 
  group_by(mes) |> 
  filter(n == max(n))

## Muestre el fabricante de los aviones que han realizado mas de cien vuelos
## durante 2013


vuelos |>
  filter(!is.na(codigo_cola)) |>
  group_by(codigo_cola) |>
  count() |>
  filter(n > 100) |> 
  left_join(select(aviones, codigo_cola, fabricante)) |> 
  ungroup() |> 
  count(fabricante)

## Observemos que la última categoría de fabricantes tiene NA, es decir
## hay 97 vuelos hechos por un avion que no existe en la tabla aviones

## Si hubiesemos utilizado inner_join() en lugar de left_join() no lo
## habriamos sabido

vuelos |>
  filter(!is.na(codigo_cola)) |>
  group_by(codigo_cola) |>
  count() |>
  filter(n > 100) |> 
  inner_join(select(aviones, codigo_cola, fabricante)) |> 
  ungroup() |> 
  count(fabricante)


## Filtre los vuelos que hayan viajado a los 10 destinos más populares del año

# Primero creamos el listado de los 10 destinos populares

destinos_populares <- vuelos |>
  count(destino, sort = TRUE) |>
  head(10)

destinos_populares

## Si quisieramos visualizar nombre completo podemos hacer

destinos_populares |> 
  inner_join(aeropuertos, 
             by = join_by("destino" == "codigo_aeropuerto")) |> 
  select(destino, n, nombre)

## Ahora utilizamos la tabla destinos_populares para filtrar vuelos

vuelos |>
  semi_join(destinos_populares) # coinciden con destino

## es similar a utilizar un filter usando %in%:

vuelos |> 
  filter(destino %in% destinos_populares$destino)

## pero se complica cuando el filtro tiene varias variables por lo que
## es más útil y sencillo el filtro usando uniones


## Muestre los código de cola de los vuelos que no tengan coincidencia dentro
## de la tabla aviones

vuelos |>
  anti_join(aviones, by = "codigo_cola") |>
  count(codigo_cola, sort = TRUE)

## Estas observaciones demuestran la falta de calidad de la base de datos


## La tabla vuelos tiene una variable llamada atraso_llegada con el atraso del
## vuelo en la llegada a su destino medida en minutos ( Valores negativos 
## indican llegada adelantada)

## Calcule el atraso promedio por destino y muestre los nombres de los 
## aeropuertos asociados de menor a mayor atraso.

vuelos |>  group_by(destino) |> 
  summarise(atraso_medio = mean(atraso_llegada, na.rm = T)) |> 
  left_join(select(aeropuertos, codigo_aeropuerto, nombre), 
            by = join_by("destino" == "codigo_aeropuerto")) |> 
  arrange(atraso_medio)

## Muestre día, mes, nombre de aeropuerto de partida, nombre de aeropuerto destino,
## nombre de la aerolínea del vuelo que demoró más (considerando el atraso de
## salida y llegada). Convierta la unidad de la demora en horas.

vuelos |> 
  mutate(dif_atraso = atraso_llegada - atraso_salida) |> 
  filter(dif_atraso == max(dif_atraso, na.rm = T)) |> 
  inner_join(select(aeropuertos, origen = codigo_aeropuerto, 
                   aeropuerto_partida = nombre)) |> 
  inner_join(select(aeropuertos, destino = codigo_aeropuerto, 
                   aeropuerto_destino = nombre)) |> 
  inner_join(aerolineas) |> 
  select(dia, mes, aeropuerto_partida, aeropuerto_destino, nombre, dif_atraso) |> 
  mutate(dif_atraso = dif_atraso/60)

## Llovió en el aeropuerto a la hora de despegue programada del vuelo anterior?

vuelos |> 
  mutate(dif_atraso = atraso_llegada - atraso_salida) |> 
  filter(dif_atraso == max(dif_atraso, na.rm = T)) |> 
  inner_join(clima, by = c("anio", "mes", "dia", "hora", "origen")) |> 
  select(precipitacion)


## Finalmente vamos a dibujar las primeras 100 rutas de los vuelos 

## creamos rutas con latitud y longitud del punto de origen y destino

rutas <-  vuelos |>
  inner_join(select(aeropuertos, codigo_aeropuerto, origen_lat = latitud, origen_lon = longitud),
             by = join_by("origen" == "codigo_aeropuerto")) |>
  inner_join(select(aeropuertos, codigo_aeropuerto, dest_lat = latitud, dest_lon = longitud),
             by = join_by("destino" == "codigo_aeropuerto"))

## graficamos con ggplot2 (creamos un maapa)

rutas |>
  slice(1:100) |>
  ggplot(aes(
    x = origen_lon, xend = dest_lon,
    y = origen_lat, yend = dest_lat
  )) +
  borders("state") +
  geom_segment(arrow = arrow(length = unit(0.1, "cm"))) +
  coord_quickmap() +
  labs(y = "Latitud", x = "Longitud")
