# Ejercitación ejemplo de Tipos de datos y NA

# 1. Active los paquetes necesarios.

library(tidyverse)
library(naniar)

# 2. Verifique el encoding de los datos almacenados en el archivo 
# defunciones_2022_Santa_Fe.csv. ¿Cuál/les es/son?

guess_encoding("defunciones_2022_Santa_Fe.csv")

# 3. Lea adecuadamente el archivo defunciones_2022_Santa_Fe.csv y almacene sus
# datos en un dataframe. Haga uso del argumento encoding de ser necesario.

datos <- read_csv2("defunciones_2022_Santa_Fe.csv")

# 4. Explore la estructura de la tabla de datos. Variables y sus tipos, cantidad de
# observaciones. Se trata de un recorte de las defunciones del año 2022
# registradas por la DEIS sucedidas en la provincia de Santa Fe.

glimpse(datos)

# 5. Seleccione y muestre en consola todas las variables que tienen un nombre que
# comienza con FEC. ¿Qué tipo de dato tienen? ¿Cuál debería ser su tipo de dato?
#   ¿Qué estructura tienen?

datos |> select(starts_with("FEC"))

# 6. Seleccione y muestre en consola todas las variables que tienen un nombre que
# termina con RES. ¿Qué tipo de dato tienen?

datos |> select(ends_with("RES"))


# unión con tablas auxiliares

# 7. Lea adecuadamente el archivo paises.csv y explórelo. Esta tabla contiene
# códigos de países que coinciden con los códigos cargados en la variable de
# defunciones llamada PAISRES y el nombre del país correspondiente.

paises <- read_csv2("paises.csv")

# 8. Utilice la tabla países para unirla con defunciones mediante el código e incorpore
# en defunciones la variable NOMBRE_USO_COMUN de países.

datos <- datos |> 
  left_join(paises |> 
              select(NOMBRE_USO_COMUN, CODIGO_INDEC), 
            by = join_by(PAISRES == CODIGO_INDEC)) 

# 9. Contabilice, como forma de comprobación, la frecuencia de los nombres de los
# países de residencia de los fallecidos durante 2022 en Santa Fe.

datos |> 
  count(NOMBRE_USO_COMUN, sort = T)

# 10. Lea adecuadamente el archivo provincias_departamentos.csv y explórelo. Esta
# tabla contiene códigos de las provincias y los departamentos de la Argentina
# asociados a sus nombres. Estos códigos están presentes en las variables de
# defunciones PROVRES Y DEPRES respectivamente.

prov_dep <- read_csv2("provincias_departamentos.csv")

# 11. Una la tabla de departamentos y provincias con la principal de defunciones
# teniendo en cuenta las variables clave de cada una. La idea es agregar los
# nombres de las provincias y departamentos de residencia en las observaciones
# de los fallecidos.

datos <- datos |> 
  left_join(prov_dep |> 
              select(Provincia, Codigo_provincia, Departamento, Codigo_departamento), 
            by = join_by(DEPRES == Codigo_departamento, PROVRES == Codigo_provincia)) 

# 12. Contabilice, al igual que en el punto 9, la frecuencia de los nombres de los
# departamentos y por otro lado de las provincias de residencia de los fallecidos
# durante 2022 en Santa Fe.

datos |> 
  count(Provincia, sort = T)

datos |> 
  count(Departamento, sort = T)


# 13. Lea adecuadamente el archivo códigos_muerte.csv y explórelo. Tiene solo dos
# variables: una con el código CIE10 y otra con su descripción. Los códigos están
# presentes en la variable de defunciones CODMUER

cod_muerte <- read_csv2("codigos_muerte.csv")

# 14. Una la tabla anterior para contar con la descripción de los códigos de muerte
# incluida dentro de la tabla de defunciones.

datos <- datos |> 
  left_join(cod_muerte,
              by = join_by(CODMUER == Codigo)) 


# 15. Volvamos a las variables del punto 5. Conviértalas en el formato adecuado y
# almacene la conversión en el mismo dataframe y con el mismo nombre de
# variables.

datos <- datos |> 
  mutate(FECDEF = dmy(FECDEF),
         FECNAC = dmy(FECNAC))

# 16. Cuando ejecute la acción anterior, el intérprete de R le va a devolver una
# advertencia. ¿Por qué ocurre?

# la advertencia es porque hay 13 observaciones en FECNAC con valores NA

sum(is.na(datos$FECNAC))

# 17. Controle si la conversión fue correcta y el tipo de dato es el adecuado.

datos |> select(where(is.Date))

# 18. Tomando en cuenta las variables fecha de nacimiento (FECNAC) y fecha de
# defunción (FECDEF) calcule la edad para cada observación, guardando el
# resultado en la misma tabla defunciones bajo el nombre edad_calculada.

datos <- datos |> 
  mutate(edad_calculada = interval(FECNAC, FECDEF)%/%dyears())

# 19. Convierta a mayúsculas los nombres de la variable Provincia (almacene el
# cambio en el dataframe defunciones).

datos <- datos |> 
  mutate(Provincia = str_to_upper(Provincia))

# 20. Necesitamos generar un nuevo dataframe denominado tuberculosis con las
# observaciones de defunciones que cumplan con la condición de que en
# CODMUER tengan la familia de códigos CIE10 A15, A16, A17, A18, A19, B19, B20
# y el código O980. La idea es que pueda construir una expresión regular que
# capture ese conjunto de datos. Puede ayudarse con alguna inteligencia artificial
# como Gemini de Google o ChatGPT de OpenIA. Tenga en cuenta que los códigos
# de CODMUER tienen 3 dígitos luego de la letra.

tuberculosis <- datos |>  
  filter(str_detect(CODMUER, "^(A1[5-9]|B[29]0)[0-9]*$|0980")) 

tuberculosis |> 
  count(Descripcion)

# 21. Convirtiendo a factor la variable SEXO, agregue etiquetas de la siguiente forma:
# a. 1 = Varon
# b. 2 = Mujer
# c. 9 = Sin especificar

datos <- datos |> 
  mutate(SEXO = factor(SEXO, 
                       labels = c("Varon", "Mujer", "Sin especificar")))

# 22. Compruebe lo realizado en el punto anterior haciendo un conteo de las
# categorías de la variable SEXO y una visualización de sus niveles.

datos |> 
  count(SEXO)

# niveles

levels(datos$SEXO)

# 23. Modifique los niveles de las categorías de SEXO haciendo que el primero sea
# Mujer. Almacene los cambios en el dataframe.

datos <- datos |> 
  mutate(SEXO = fct_relevel(SEXO, "Mujer"))

levels(datos$SEXO)

# 24. Obtenga el valor máximo de la variable EDAD original en todo el dataframe con
# las defunciones. ¿Qué tiene de malo ese valor? ¿Por qué sospecha que sucede?
  
datos |> 
  summarise(maximo_edad = max(EDAD))

# 25. Utilizando funciones del paquete naniar, reemplace los valores de las
# observaciones de EDAD que tengan el valor máximo encontrado anteriormente
# por NA.

datos <- datos |> 
  replace_with_na(replace = list(EDAD = 999))

# 26. Utilizando funciones del paquete naniar, muestre en un gráfico la proporción de
# valores faltantes (NA) de todas las variables del dataframe de defunciones.

datos |> 
  gg_miss_var(show_pct = T) 

# 27. Utilizando funciones del paquete naniar, construya un gráfico UpSet que
# muestre el patrón de valores faltantes del dataframe. Setee el argumento 
# nsets = 6.

datos |> 
  gg_miss_upset(nsets = 6) 
  
# 38. Construya un nuevo dataframe llamado provincia_completa, producto de
# eliminar las observaciones del dataframe defunciones donde en la variable
# Provincia haya valores perdidos (NA).

provincia_completa <- datos |> 
  drop_na(Provincia)

