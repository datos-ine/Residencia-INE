## Script Visualización de datos

library(tidyverse)
library(readxl)

datos <- read_excel("base2023r.xlsx")

glimpse(datos)

# Capas geométricas

# Tomamos una variable cuantitativa continúa como EDAD_DIAGNOSTICO

# Histograma (por defecto son 30 bins)

datos |> 
  ggplot(aes(x = EDAD_DIAGNOSTICO)) +
  geom_histogram()

# cambiamos la cantidad de bins

datos |> 
  ggplot(aes(x = EDAD_DIAGNOSTICO)) +
  geom_histogram(bins = 10)

# cambiamos ancho de bins (intervalo de clase)

datos |> 
  ggplot(aes(x = EDAD_DIAGNOSTICO)) +
  geom_histogram(binwidth = 10)   # cada 10 años


# personalizamos colores y configuramos escala del eje x

datos |> 
  ggplot(aes(x = EDAD_DIAGNOSTICO)) +
  geom_histogram(binwidth = 10, 
                 fill = "maroon", 
                 color = "white") +
  scale_x_continuous(breaks = seq(0,100, by = 10))

# estratificado por una variable categórica (SEXO)

datos |> 
  filter(SEXO != "A") |> 
  ggplot(aes(x = EDAD_DIAGNOSTICO)) +
  geom_histogram(binwidth = 10, 
                 fill = "maroon", 
                 color = "white") +
  scale_x_continuous(breaks = seq(0,100, by = 10)) + 
  facet_wrap(. ~ SEXO)

# separamos colores de relleno por mapeo de SEXO

datos |> 
  filter(SEXO != "A") |>            # eliminamos categoría de baja frecuencia 
  ggplot(aes(x = EDAD_DIAGNOSTICO, fill = SEXO)) +
  geom_histogram(binwidth = 10, 
                 color = "white") +
  scale_x_continuous(breaks = seq(0,100, by = 10)) + 
  scale_fill_manual(values = c("gold3", "olivedrab")) +
  facet_wrap(. ~ SEXO)

#  otra opción es hacer un gráfico de densidad

datos |> 
  ggplot(aes(x = EDAD_DIAGNOSTICO)) +
  geom_density(fill = "skyblue3") +
  scale_x_continuous(breaks = seq(0,100, by = 10))

# se pueden mostrar las distribuciones por SEXO en el mismo gráfico

datos |> 
  filter(SEXO != "A") |> 
  ggplot(aes(x = EDAD_DIAGNOSTICO, fill = SEXO)) +
  geom_density(alpha = 0.5) +          # alpha es la opacidad al 50 %
  scale_x_continuous(breaks = seq(0,100, by = 10)) +
  scale_fill_manual(values = c("gold3", "skyblue3")) 


# otra forma es mediante boxplot

datos |> 
  ggplot(aes(x = EDAD_DIAGNOSTICO)) +
  geom_boxplot(fill = "seagreen3")

# lo puedo invertir con coord_flip()

datos |> 
  ggplot(aes(x = EDAD_DIAGNOSTICO)) +
  geom_boxplot(fill = "seagreen3") +
  coord_flip()

# también definiendo la variable en y

datos |> 
  ggplot(aes(y = EDAD_DIAGNOSTICO)) +
  geom_boxplot(fill = "seagreen3")

# estratificamos por sexo

datos |> 
  filter(SEXO != "A") |> 
  ggplot(aes(y = EDAD_DIAGNOSTICO, fill = SEXO)) +
  geom_boxplot() +
  scale_fill_brewer(palette = "Set1") # usamos paleta Set1 de Brewer

# agregamos capa jitter

datos |> 
  filter(SEXO != "A") |> 
  ggplot(aes(x = SEXO, y = EDAD_DIAGNOSTICO, fill = SEXO)) +
  geom_boxplot() +
  geom_jitter(width = 0.25, alpha = 0.6) +
  scale_fill_brewer(palette = "Set1")

## como violin plot 

datos |> 
  filter(SEXO != "A") |> 
  ggplot(aes(x = SEXO, y = EDAD_DIAGNOSTICO, fill = SEXO)) +
  geom_violin() +
  scale_fill_brewer(palette = "Set2") 


# Ahora tomamos una variable cualitativa como PROVINCIA_RESIDENCIA

# Gráfico de barras

datos |> 
  ggplot(aes(x = PROVINCIA_RESIDENCIA)) +
  geom_bar() 

# usamos fct_infreq() para ordenar por frecuencias

datos |> 
  ggplot(aes(x = fct_infreq(PROVINCIA_RESIDENCIA))) +
  geom_bar() 

# Agregamos color fijo y reducimos ancho de barras

datos |> 
  ggplot(aes(x = fct_infreq(PROVINCIA_RESIDENCIA))) +
  geom_bar(fill = "chocolate3", width = 0.5) 

# Cambiamos color mapeado con paleta de colores 
# (debe ser una paleta que tenga al menos la misma cantidad de colores que
# categorías tenga la variable)

library(RColorBrewer)

conteo_colores <-  length(unique(datos$PROVINCIA_RESIDENCIA))

conteo_colores  

# 18 colores a crear por la nueva paleta

nueva_paleta <- colorRampPalette(brewer.pal(8, "Set2"))

datos |> 
  ggplot(aes(x = fct_infreq(PROVINCIA_RESIDENCIA))) +
  geom_bar(fill = nueva_paleta(conteo_colores))

# cambiamos etiquetas de ejes y posición de categorías de x

datos |> 
  ggplot(aes(x = fct_infreq(PROVINCIA_RESIDENCIA))) +
  geom_bar(fill = nueva_paleta(conteo_colores)) +
  labs(x = "Frecuencia", 
       y = "Provincias") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))


# agregamos etiquetas con valores 

# para lograr esto debemos hacer el conteo previamente, 
# luego reordenar con fct_reorder() y utilizar la frecuencia en y,
# definir "identity" en stats del geom_bar() y agregar label en aes()
# mas la capa de texto (también puede usarse la capa de label)

datos |> 
  count(PROVINCIA_RESIDENCIA, 
        name = "Frec") |> 
  ggplot(aes(x = fct_reorder(PROVINCIA_RESIDENCIA, desc(Frec)), 
             y = Frec,
             label = Frec)) +
  geom_bar(stat = "identity", 
           fill = nueva_paleta(conteo_colores)) +
  geom_text(nudge_y = 2) +
  labs(x = "Frecuencia", 
       y = "Provincias") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))


datos |> 
  count(PROVINCIA_RESIDENCIA, 
        name = "Frec") |> 
  ggplot(aes(x = fct_reorder(PROVINCIA_RESIDENCIA, desc(Frec)), 
             y = Frec,
             label = Frec)) +
  geom_bar(stat = "identity", 
           fill = nueva_paleta(conteo_colores)) +
  geom_label(nudge_y = 4) +
  labs(x = "Frecuencia", 
       y = "Provincias") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

# cambiamos de tema preconfigurado

datos |> 
  ggplot(aes(x = fct_infreq(PROVINCIA_RESIDENCIA))) +
  geom_bar(fill = nueva_paleta(conteo_colores)) +
  labs(x = "Frecuencia", 
       y = "Provincias") +
  theme_minimal() +           # tema minimo
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

datos |> 
  ggplot(aes(x = fct_infreq(PROVINCIA_RESIDENCIA))) +
  geom_bar(fill = nueva_paleta(conteo_colores)) +
  labs(x = "Frecuencia", 
       y = "Provincias") +
  theme_test() +           # tema test
  theme(axis.text.x = element_text(angle = 45, hjust = 1))

## personalización de theme

# La función theme() permite personalizar las partes del gráfico, por ejemplo:

## creamos un tema estético general para nuestros gráficos

## Fuentes

# Para usar una fuente personalizada, es necesario instalar los archivos 
# de fuente .ttf o .otf en la máquina local. Aca estamos usando los conocidos 
# tipos de letra Roboto que están disponibles a través de GoogleFonts:

# https://fonts.google.com/specimen/Roboto?query=roboto

# Deberiamos descargar e intalar Roboto fonts en nuestra PC antes de proseguir


## configuramos el tema personalizado

mi_tema <- theme_void() + theme(
  plot.title = element_text(family = "Roboto", face = "bold", size = 18), 
  plot.caption = element_text(family = "Roboto",face = "italic", size = 10, color = "gray30", hjust = 0), 
  axis.text.x = element_text(family = "Roboto",color = "black", size = 12, 
                             margin = margin(t = 6)),
  axis.text.y = element_text(family = "Roboto",color = "black", size = 12, hjust = 1, 
                             margin = margin(r = 6)),
  axis.line.x = element_line(color = "black", linewidth = 1),
  panel.grid.major.y = element_line(color = "grey90", linewidth = 0.6),
  plot.background = element_rect(fill = "white", color = "white"),
  plot.margin = margin(rep(20, 4))
)

# tomamos uno de los grafcos anteriores y agregamos titlo, etiquetas de ejes 
# y pie de gráfico

datos |> 
  ggplot(aes(x = EDAD_DIAGNOSTICO)) +
  geom_histogram(binwidth = 10, 
                 fill = "maroon", 
                 color = "white") +
  scale_y_continuous(limits = c(0,50), breaks = seq(0,50, 5)) +
  scale_x_continuous(breaks = seq(0,100, by = 10)) + 
  labs(x = "Frecuencia", 
       y = "Edad", 
       title = "Histograma de edad", 
       caption = "Ejemplo curso R INE 2024") + 
  mi_tema   # agregamos tema al gráfico

## Gráfico Upset

# Este gráfico que vimos con valores NA provisto por el paquete naniar, llamado
# análisis de respuesta múltiple o análisis de combinaciones permite mostrar
# variables no excluyentes como grupo de síntomas o comorbilidades. 

# El paquete que lo realiza es UpSetR que deberán instalar.

# Hay que hacer un procedimiento previo con los datos, dado que las variables 
# deben tener valores 1 y 0, para si o no respectivamente.


library(UpSetR)


datos_upset1 <- datos |> 
  mutate(DIABETES = if_else(DIABETES == "Sí", 1, 0),
         ENF_RESP_CRONICA = if_else(ENF_RESP_CRONICA == "SI", 1, 0),
         VIH = if_else(VIH == "Positivo", 1, 0)) |> 
  select(DIABETES, ENF_RESP_CRONICA, VIH)

# la función upset funciona en dataframes viejos por lo que no es compatible
# con los tibbles de tidyverse

# lo solucionamos conviertiendo en dataframe tradicional

datos_upset1 <- as.data.frame(datos_upset1)

upset(datos_upset1,
    sets = c("DIABETES", "ENF_RESP_CRONICA", "VIH"),
    order.by = "freq",
    sets.bar.color = c("royalblue", "firebrick", "gold"), 
    empty.intersections = "on",
    point.size = 2,
    line.size = 1, 
    mainbar.y.label = "Factores de riesgo",
    sets.x.label = "Observaciones")


# otra posibilidad es usar el paquete ggupset comptaible con ggplot2
# que trae una capa especial para estos gráficos

library(ggupset)

# esta capa necesita que los valores estén en un formato especial, 
# llamado columna-lista (es como un formato lista dentro de una variable)


datos_upset2 <- datos |> 
  mutate(DIABETES = if_else(DIABETES == "Sí", "DIABETES", NA), 
         ENF_RESP_CRONICA = if_else(ENF_RESP_CRONICA == "SI", "ENF_RESP_CRONICA", NA), 
         VIH = if_else(VIH == "Positivo", "VIH", NA)) |> 
  unite(col = "comorbilidades",
        c(DIABETES, ENF_RESP_CRONICA, VIH), 
        sep = "; ",
        remove = TRUE,
        na.rm = TRUE) |>  
  mutate(comorbilidades_lista = as.list(str_split(comorbilidades, "; ")) 
  )


# una vez creada la variable especial ya podemos utilizarla dentro de un ggplot 
# con la capa scale_x_upset() de ggupset

datos_upset2 |> 
  ggplot(aes(x = comorbilidades_lista)) +
  geom_bar() +
  scale_x_upset(
    reverse = FALSE,
    n_intersections = 10,
    sets = c("DIABETES", "ENF_RESP_CRONICA", "VIH"))+
  labs(
    title = "Comorbilidades",
    x = "Combinación de comorbilidades",
    y = "Frecuencia")  


