### Mas allá de los gráficos de barras y boxplots

## Paquetes

library(tidyverse)     ## un viejo conocido
library(colorspace)    ## manejo de espacio de colores
library(rcartocolor)   ## paletas de colores
library(ggforce)       ## graficos sina
library(ggdist)        ## graficos halfeye 
library(ggridges)      ## graficos ridgeline 
library(ggbeeswarm)    ## graficos beeswarm 
library(gghalves)      ## off-set jitter
library(systemfonts)   ## fuentes personalizadas

## tema estético general para ggplot2

## Fuente

# Para usar una fuente personalizada, es necesario instalar los archivos 
# de fuente .ttf o .otf en la máquina local. Aca estamos usando los conocidos 
# tipos de letra Roboto que están disponibles a través de GoogleFonts:

# https://fonts.google.com/specimen/Roboto?query=roboto

# Deberiamos descargar e intalar Roboto fonts antes de proseguir.


theme_set(theme_void(base_family = "Roboto"))


## Otras caracteristicas de tema

theme_update(
  axis.text.x = element_text(color = "black", face = "bold", size = 22, 
                             margin = margin(t = 6)),
  axis.text.y = element_text(color = "black", size = 18, hjust = 1, 
                             margin = margin(r = 6), family = "Roboto Mono"),
  axis.line.x = element_line(color = "black", size = 1),
  panel.grid.major.y = element_line(color = "grey90", size = 0.6),
  plot.background = element_rect(fill = "white", color = "white"),
  plot.margin = margin(rep(20, 4))
)


## tema para gráficos horizontales
theme_flip <- theme(
    axis.text.x = element_text(face = "plain", family = "Roboto Mono", size = 20),
    axis.text.y = element_text(face = "bold", family = "Roboto", size = 22),
    panel.grid.major.x = element_line(color = "grey90", size = .6),
    panel.grid.major.y = element_blank(),
    legend.position = "top", 
    legend.text = element_text(family = "Roboto Mono", size = 16),
    legend.title = element_text(face = "bold", size = 16, margin = margin(b = 25))
  )




## Lectura de datos

## Vamos a utilizar un conjunto de datos ficticio que consta de cuatro grupos 
## con diferentes tamaños de muestra y distribuciones de algunos valores.

datos <- read_csv2("distribuciones ficticias.csv")


# Estos datos pertenecen al sitio flipbook by Nico Riedel, Robert Schulz, 
# and Tracey Weissgerber (https://osf.io/vt2ny/).

## Colores personalizados 

mi_pal <- rcartocolor::carto_pal(n = 8, name = "Bold")[c(1, 3, 7, 2)]

mi_pal  # tema de 4 colores (uno por cada grupo)


## Exploración

glimpse(datos)

datos |> 
  group_by(grupo) |> 
  summarise(media = mean(valor),
            desvio = sd(valor),
            minimo = min(valor),
            maximo = max(valor),
            mediana = median(valor),
            rango_inter = IQR(valor),
            n = n())

## Gráficos resumen

### Gráficos de barras

## Para conteos (n)

datos |> 
  ggplot(aes(x = grupo, fill = grupo)) +
  geom_bar(width = 0.8) +
  scale_y_continuous() +
  scale_fill_manual(values = mi_pal, guide = "none")

## Para estadísticas (stat = "summary")

datos |> 
  ggplot(aes(x = grupo, y = valor, fill = grupo)) +
  geom_bar(stat = "summary", width = 0.8) +
  scale_y_continuous(limits = c(0, 4.5), 
                     breaks = seq(0,4.5, by = 0.5)) + 
  scale_fill_manual(values = mi_pal, guide = "none")



### Grafico dinamita

## Los diagramas de dinamita se utilizan para comparar mediciones de dos o más 
## grupos: casos y controles, por ejemplo. En una comparación de dos grupos, 
## lo graficado es una representacón gráfica de solo 4 números, 
## independientemente del tamaño de la muestra. Los cuatro números son el 
## promedio y el error estándar (o la desviación estándar, no siempre está claro) 
## para cada grupo. 

## Rafael Irizarry, *"Los graficos de dinamita deben morir"*


datos |> ggplot(aes(x = grupo, y = valor, color = grupo, fill = grupo)) +
  stat_summary(
    geom = "errorbar",
    fun.max = function(x) mean(x) + sd(x),
    fun.min = function(x) mean(x) - sd(x),
    width = 0.3, size = 1.2) +
  scale_y_continuous(limits = c(0, 6), breaks = seq(0,6, by = 0.50)) +
  scale_color_manual(values = mi_pal, guide = "none")


## con barras + errobar

datos |> ggplot(aes(x = grupo, y = valor, color = grupo, fill = grupo))  +
geom_bar(stat = "summary", width = 0.8, size = 0.8) +
  scale_y_continuous(limits = c(0, 6), breaks = seq(0,6, by = 0.50)) +
  scale_fill_manual(values = mi_pal, guide = "none") +
  scale_color_manual(values = mi_pal, guide = "none") +
  stat_summary(
    geom = "errorbar",
    fun.max = function(x) mean(x) + sd(x),
    fun.min = function(x) mean(x) - sd(x),
    width = 0.3, size = 1.2, color = "black"
  ) 

### Gráficos Boxplot


g <- datos |> 
  ggplot(aes(x = grupo, y = valor, color = grupo, fill = grupo)) +
  scale_y_continuous(limits = c(0, 6), breaks = seq(0,6, by = 0.50)) +
  scale_color_manual(values = mi_pal, guide = "none") +
  scale_fill_manual(values = mi_pal, guide = "none")

## primera versión

g + geom_boxplot(alpha = 0.5, size = 1.5, outlier.size = 5)


## Si bien los boxplot son muy efectivos y se usan ampliamente en el análisis 
## de datos, tienen la limitación de que solo muestran puntos estadísticos 
## específicos, como el promedio de la mediana o valores atípicos, 
## en lugar de la distribución de un conjunto de datos como un todo.

### Gráficos de Violin 

## Los diagramas de violín se enfocan en ilustrar la distribución de todo 
## el conjunto de datos y pueden mostrar diferentes conocimientos, que están 
## ocultos en la estructura de los boxplot.

g + geom_violin(aes(fill = grupo),
    size = 1.2, alpha = 0.8)

## Por defecto, define el argumento bw  = "nrd0".
## bw.nrd0 implementa una regla empírica para elegir el ancho de banda de 
## un estimador de densidad del núcleo gaussiano. 
## El valor predeterminado es 0,9 veces el mínimo de la desviación estándar 
## y el rango intercuartílico dividido por 1,34 veces el tamaño de la muestra 
## a la quinta potencia negativa (= "regla general" de Silverman, Silverman 
## (1986, página 48, ecuación (3.31)) ) a menos que los cuartiles coincidan 
## cuando se garantizará un resultado positivo.


## Cambiando el ancho de banda de suavizado que se utiliza.
## El número es el desvío estándar del kernel gaussiano de suavizado en la
## distribución de densidad.

g + geom_violin(aes(fill = grupo),
    size = 1.2, alpha = 0.8, bw = 0.2)  # 0.2

## bw = 0.8

g + geom_violin(aes(fill = grupo),
    size = 1.2, alpha = 0.8, bw = 0.8)

## bw = 0.05

g + geom_violin(aes(fill = grupo),
    size = 1.2, alpha = 0.8, bw = 0.05)

####

## Aplicando ggdist para graficos halfeye 

## Gráficos que une densidad de distribución con intervalo

g + stat_halfeye(aes(fill = grupo), alpha = 0.7) 

## cambiando el ancho de banda de la densidad con argumento adjust

g + stat_halfeye(aes(fill = grupo), alpha = 0.7,
                 adjust = 0.2, position = position_nudge(x = -0.3))

## modificando la extensión del intervalo y el tamaño del punto medio

g + stat_halfeye(aes(fill = grupo), 
                 alpha = 0.7,
                 .width = 1, 
                 point_size = 5, 
                 adjust = 0.2, 
                 position = position_nudge(x = -0.3))


### Gráficos Ridgeline 

## Los diagramas de Ridgeline son diagramas de líneas parcialmente 
## superpuestas que crean la impresión de una cadena montañosa. 
## Pueden ser muy útiles para visualizar cambios en las distribuciones 
## a lo largo del tiempo o el espacio`

g_ridges <- datos |>  
  ggplot(aes(valor, fct_rev(grupo), color = grupo, fill = grupo)) + 
  coord_cartesian(clip = "off") +
  scale_color_manual(values = mi_pal, 
                     guide = "none") +
  scale_fill_manual(values = mi_pal, 
                    guide = "none") +
  theme_flip

## primera versión

g_ridges + geom_density_ridges(alpha = 0.7, 
                               size = 1.5)

## acortamos solo la distribución

g_ridges + geom_density_ridges(alpha = 0.8, 
                               size = 1.5, 
    rel_min_height = 0.01)

# con escala de color gradiente

g_ridges + 
  geom_density_ridges_gradient(aes(fill = stat(x)), 
                               color = "black",
                               size = 1.5, 
                               rel_min_height = 0.01) +
  scale_fill_viridis_c(option = "mako",
                       direction = -1, 
                       guide = "none", 
                       end = 0.9)

## agregando la mediana (quantiles = 2)

g_ridges + 
  stat_density_ridges(
    quantile_lines = TRUE, 
    quantiles = 2, 
    color = "black", 
    alpha = 0.8, 
    size = 1.5) 


## generamos paleta de colores para cuartiles

q_pal <- lighten(carto_pal(n = 4, name = "Geyser")[c(2, 1, 4, 3)], 0.6)

# otra paleta posble

# q_pal <- colorspace::adjust_transparency(rcartocolor::carto_pal(n = 4, name = "Tropic")[c(2, 1, 4, 3)], alpha = .7)

## con cuartiles de diferentes colores

g_ridges + 
    stat_density_ridges(
    aes(fill = factor(stat(quantile))),
    geom = "density_ridges_gradient", calc_ecdf = TRUE, quantiles = 4, 
    color = "black", size = 1
  ) +
  scale_fill_manual(values = q_pal, name = "Cuartiles:") +
  guides(fill = guide_legend(override.aes = list(color = "transparent")))

## con bandas de probabilidades (95%)

g_ridges + 
  stat_density_ridges(
    aes(fill = factor(stat(quantile))),
    geom = "density_ridges_gradient", calc_ecdf = TRUE,
    quantiles = c(0.025, 0.975),
    color = "black", size = 1.5
  ) +
  scale_fill_manual(
    name = "Probabilidad:", values = c("#994c00", "grey70", "#003366"),
    labels = c("(0, 0.025]", "(0.025, 0.975]", "(0.975, 1]")
  ) +
  guides(fill = guide_legend(override.aes = list(color = "transparent")))


### Tiras de intervalos

g_intervalos <- datos |> 
  ggplot(aes(grupo, valor)) +
  scale_color_viridis_d(
    option = "mako", name = "Nivel:", direction = -1, 
    begin = 0.15, end = 0.9
  ) +
  guides(
    color = guide_legend(reverse = TRUE, title.position = "top")
  ) +
  scale_y_continuous(limits = c(0, 7), breaks = seq(0,7, by = 0.50)) +
  theme(
    legend.position = c(0.75, 0.95), legend.direction = "horizontal",
    legend.text = element_text(family = "Roboto Mono", size = 18),
    legend.title = element_text(face = "bold", size = 22, hjust = 0.5)
  )

## primera versión (vector de probabilidades predeterminado)

g_intervalos +
  stat_interval(size = 12)

## cambiando las probabilidades con .width)

g_intervalos +
  stat_interval(.width = c(0.25, 0.5, 0.95, 1), size = 12)

## mejorando etiquetas

g_intervalos +
  stat_interval(.width = c(0.25, 0.5, 0.95, 1), size = 12) +
  scale_color_viridis_d(
    option = "mako", name = "Nivel:", direction = -1, 
    begin = 0.15, end = 0.9,
    labels = function(x) paste0(as.numeric(x)*100, "%")
  )

## agregamos un circulo en la mediana

g_intervalos +
  stat_interval(.width = c(0.25, 0.5, 0.95, 1), size = 12) +
  stat_summary(
    geom = "point", fun = median,
    color = "white", size = 4, shape = 1, stroke = 1.6
  ) +
  scale_color_viridis_d(
    option = "mako", name = "Nivel:", direction = -1, 
    begin = .15, end = .9,
    labels = function(x) paste0(as.numeric(x)*100, "%")
  ) 

## fusionamos con un halfeye 

g_intervalos +
  stat_interval(
    .width = c(0.25, 0.5, 0.95, 1), 
    size = 7
  ) +
  stat_halfeye(
    adjust = 0.33, ## bandwidth
    width = 0.7, fill = "grey85",
    interval_colour = NA, point_colour = "black",
    shape = 23, stroke = 1.5, point_size = 5, point_fill = "white",
    position = position_nudge(x = .03),
    aes(thickness = stat(f*n))
  ) +
  scale_color_viridis_d(
    option = "mako", name = "Nivel:", direction = -1, 
    begin = 0.15, end = 0.9,
    labels = function(x) paste0(as.numeric(x)*100, "%")
  )


### Intervalos con gradientes


g + stat_gradientinterval(width = 0.3, color = "black")


### Gráfico de dispersión 


g + geom_point(size = 10, alpha = 0.33)


### Gráfico barra de códigos 


g + geom_point(shape = 95, size = 50, alpha = 0.33)


### Gráficos Jitter 

## control de ancho predeterminado

g + geom_jitter(size = 7, alpha = 0.5)

## control de ancho manual a 0.2

g + geom_jitter(size = 7, alpha = 0.5, width = 0.2)

## con geom_point y position_jitter

g + geom_point(position = position_jitter(width = 0.2, seed = 0),
    size = 7, alpha = 0.5)

## agregamos borde

g + geom_point(position = position_jitter(width = 0.2, seed = 0),
    size = 7, alpha = 0.5) +
  geom_point(position = position_jitter(width = 0.2, seed = 0),
    size = 7, stroke = 0.9, shape = 1, color = "black")


### Sina Plot (jitter mejorado en cuanto a la distribución)

# El gráfico sina es un gráfico de visualización de datos adecuado para 
# trazar cualquier variable individual en un conjunto de datos multiclase. 
# Es un gráfico de franjas de fluctuación mejorado, donde el ancho de la 
# fluctuación está controlado por la distribución de densidad de los datos 
# dentro de cada clase. 

g + geom_sina(maxwidth = 0.6, 
              scale = "count", 
              seed = 1,
              size = 7, 
              alpha = 0.5) + 
    geom_sina(maxwidth = 0.6, 
              scale = "count", 
              seed = 1, 
              size = 7, 
              shape = 1, 
              color = "black", 
              stroke = 0.8)


### Dot plot

# Un dot plot es un gráfico estadístico que consta de puntos de datos trazados 
# en una escala bastante simple, generalmente usando círculos rellenos. 
# Hay dos versiones comunes del gráfico de puntos. Leland Wilkinson describe 
# el primero como un gráfico que se ha utilizado en gráficos dibujados a mano 
# (era anterior a la computadora) para representar distribuciones. 
# William Cleveland describe la otra versión como una alternativa al gráfico
# de barras, en el que se utilizan puntos para representar los valores 
# cuantitativos (por ejemplo, recuentos) asociados con variables categóricas

g + stat_dots(position = position_nudge(x = -0.25))

## ambos lados

g + stat_dots(side = "both")

## forma "weave"

g + stat_dots(layout = "weave", position = position_nudge(x = -0.25))


### Gráfico de enjambre de abejas (beeswarm) con stats_dots


g + stat_dots(layout = "swarm", side = "both")

## con geom_beeswarm()

g + geom_beeswarm(size = 5, cex = 3)

## con geom_quasirandom() y algunas modificaciones estéticas

g + geom_quasirandom(size = 8,
                     width = 0.33, 
                     alpha = 0.7) + 
    geom_quasirandom(size = 8, 
                     width = 0.33, 
                     shape = 1, 
                     color = "black", 
                     stroke = 0.8)


## Gráficos hibridos

### Beeswarm quasirandom con indicador de mediana

g + geom_quasirandom(size = 8, 
                     width = 0.33, 
                     alpha = 0.3) +
    stat_summary(fun = median, 
                 geom = "point", 
                 shape = 95, 
                 size = 50) + 
    ggbeeswarm::geom_quasirandom(size = 8, 
                                 width = 0.33, 
                                 shape = 1, 
                                 color = "black", 
                                 stroke = 0.8)


### Boxplot y Jitter 

g + geom_boxplot(aes(fill = grupo),
                 size = 1.5, 
                 outlier.shape = NA, 
                 alpha = 0.7) +
    geom_jitter(width = 0.1, 
                size = 7, 
                alpha = 0.5)

## agregamos brode blanco en circulos

g + geom_boxplot(aes(fill = grupo),
                 size = 1.5, 
                 outlier.shape = NA, 
                 alpha = 0.7) +
    geom_point(position = position_jitter(width = 0.1, seed = 0),
               size = 7, 
               alpha = 0.5) +
    geom_point(position = position_jitter(width = .1, seed = 0),
               size = 7, 
               stroke = 0.9, 
               shape = 1, 
               color = "white")


### Box Plot y Violin 


g + geom_violin(aes(fill = grupo),
                size = 1.2, 
                bw = 0.2, 
                alpha = 0.7) + 
    geom_boxplot(fill = "white",  
                 size = 1.2, 
                 width = 0.2, 
                 outlier.size = 5)

## mostramos solo la caja del boxplot

g + geom_violin(aes(fill = grupo),
                size = 1.2, 
                bw = 0.2, 
                alpha = 0.7) + 
    geom_boxplot(fill = "white",  
                 size = 1.2, 
                 width = 0.2, 
                 outlier.shape = NA, 
                 coef = 0)

## otro estilo de boxplot con mediana marcada (circulo blanco)

g + geom_violin(aes(fill = grupo),
                size = 1.2, 
                bw = 0.2, 
                color = NA, 
                alpha = 0.7) +
    geom_boxplot(width = 0.1, 
                 size = 1.2, 
                 outlier.shape = NA) +
    stat_summary(geom = "point",
                 fun = median,
                 color = "white",
                 size = 5)


### Boxplot, Violin y Jitter 

g + geom_violin(aes(fill = grupo),
                size = 1.2, 
                bw = 0.2, 
                alpha = 0.5) + 
    geom_boxplot(fill = "white",  
                 size = 1.2, 
                 width = 0.2, 
                 outlier.shape = NA, 
                 coef = 0) +
    geom_point(position = position_jitter(width = 0.03, seed = 0),
               size = 5, 
               alpha = 0.5) +
    geom_point(position = position_jitter(width = 0.03, seed = 0),
               size = 5, 
               stroke = 0.7, 
               shape = 1, 
               color = "black")


### Boxplot, Violin y Beeswarm (puntos pequeños)

g + geom_violin(aes(fill = grupo),
                size = 1.2, 
                bw = 0.2, 
                alpha = 0.7) + 
    geom_boxplot(fill = "white",  
                 size = 1.2, 
                 width = 0.2, 
                 outlier.shape = NA, 
                 coef = 0) + 
    stat_dots(layout = "swarm", 
              side = "both", 
              stackratio = 0.25, 
              dotsize = 0.1, 
              alpha = 0.5) + 
    stat_dots(layout = "swarm", 
              side = "both",
              stackratio = 0.25, 
              dotsize = 0.1,
              shape = 1, 
              color = "black", 
              stroke = 0.8)



### Violin y Sina 

g + geom_violin(aes(fill = grupo),
                size = 1.2, 
                bw = 0.2, 
                width = 0.6, 
                scale = "count", 
                alpha = 0.7) +
    stat_summary(geom = "point", 
                 fun = median,
                 shape = 23, 
                 size = 6, 
                 color = "black", 
                 stroke = 1.5) + 
    geom_sina(maxwidth = 0.5, 
              scale = "count", 
              size = 3, 
              alpha = 0.5, 
              seed = 0) + 
    geom_sina(maxwidth = 0.5, 
              scale = "count", 
              size = 3, 
              alpha = 0.5, 
              seed = 0,
              shape = 1, 
              color = "black", 
              stroke = 0.8)


## Gráficos Raincloud 

# Un enfoque de visualización de datos que proporciona la máxima 
# información estadística al tiempo que conserva la naturaleza deseada
# de "inferencia de un vistazo" de los diagramas de barras y otros 
# dispositivos de visualización similares. Estos "gráficos de nubes de 
# lluvia" pueden visualizar datos sin procesar, densidad de probabilidad 
# y estadísticas de resumen, como la mediana, la media y los intervalos 
# de confianza relevantes en un formato atractivo y flexible con 
# redundancia mínima.

g + geom_boxplot(width = 0.2, 
                 fill = "white",
                 size = 1.5, 
                 outlier.shape = NA) +
    stat_halfeye(adjust = 0.33, ## bandwidth
                 width = 0.67, 
                 color = NA, ## remove slab interval
                 position = position_nudge(x = 0.15)) +
    geom_half_point(side = "l", 
                    range_scale = 0.3, 
                    alpha = 0.5, 
                    size = 3)


## formato horizontal

datos |> ggplot(aes(x = forcats::fct_rev(grupo), 
                     y = valor, 
                     color = grupo, 
                     fill = grupo)) +
  geom_boxplot(width = 0.2, 
               fill = "white",
               size = 1.5, 
               outlier.shape = NA) +
  stat_halfeye(adjust = 0.33,
               width = 0.67, 
               color = NA,
               position = position_nudge(x = 0.15)) +
  geom_half_point(side = "l", 
                  range_scale = 0.3, 
                  alpha = 0.5, 
                  size = 3) +
  coord_flip() +
  scale_y_continuous(breaks = 1:9) +
  scale_color_manual(values = mi_pal, guide = "none") +
  scale_fill_manual(values = mi_pal, guide = "none") +
  theme_flip

## Raincloud con códigos de barras y boxplot

g + geom_boxplot(width = 0.2, 
                 fill = "white",
                 size = 1.5, 
                 outlier.shape = NA) +
    stat_halfeye(adjust = 0.33, 
                 width = 0.55, 
                 color = NA, 
                 position = position_nudge(x = 0.14)) +
    geom_point(position = position_nudge(x = -0.22),
               shape = 95, 
               size = 24, 
               alpha = 0.25)



