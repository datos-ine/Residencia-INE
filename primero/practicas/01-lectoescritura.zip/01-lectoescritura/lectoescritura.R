## Lectura y escritura de datos

## Estando dentro de un proyecto nos vamos a desentender de la ubicación de
## los archivos que deseemos leer, dado que siempre las funciones de lectura
## buscaran en la carpeta asociada al proyecto.

## Por lo tanto, los archivos de datos deberán guardarse dentro de esa carpeta
## o en algun subdirectorio de la carpeta del proyecto

## Los paquetes que usaremos para la lectura y escritura de archivos de datos
## pertenecientes al tidyverse son principalmente readr y readxl (para archivos
## de texto plano tipo csv y Excel respectivamente). También mostraremos como 
## trabajar con archivos Apache parquet.

## Comentamos que el paquete pak tiene un sistema de instalación de paquetes 
## destacado por su flujo de trabajo en paralelo. A continuación vamos a mostrarlo:

install.packages("pak")

## instalamos los dos paquetes 

pak::pak(pkg = c("tidyverse", "arrow"))

# Ahora los activamos

library(tidyverse)
library(arrow)

## En RStudio podemos visualizar el contenido desde el panel Files

#  o bien podemos ejecutar:

dir()  #devuelve el contenido del directorio de trabajo (carpeta del proyecto)

## Archivos texto plano

## Para determinar la forma de lectura de archivos tipo csv o de texto plano
## separados por algún caracter necesitamos que nos indiquen previamente el
## formato o debemos investigar por nuestra cuenta.

## Vamos a tratar de leer el archivo "Dieta.csv" 

## Para esto podemos utilizar el panel File y pulsando sobre el archivo 
## visualizar el contenido con View File

## Debemos prestar atención a la cabecera del archivo y al caracter que aparece 
## separando las columnas.

## En este caso vemos que tiene cabecera y el separador es la coma (,)

## Podemos utilizar read_csv() de readr, pero antes tenemos que activar tidyverse

read_csv(file = "Dieta.csv")

## read_csv() efectivamente hizo la lectura pero solo lo muestra en consola

## Por qué?

## Bien, porque necesitamos asignar la lectura a un nombre que será el nombre
## del dataframe 

dieta <- read_csv(file = "Dieta.csv")

## Que pasa si me equivoco y aplico mal la función, por ejemplo:

read_csv2(file = "Dieta.csv")

# Una primera revisión, cada vez que hacemos alguna lectura, es verificar
# la cantidad de variables

## Ahora hagámoslo con el archivo "CancerMama.csv"


# Qué sucede con el nombre de la tercer columna?


## Veamos si podemos solucionarlo importando desde el menú de RStudio (Import Dataset)

## INSERTAMOS AQUÍ EL CÓDIGO GENERADO POR IMPORT DATASET


## probemos detectar el encoding 

guess_encoding("CancerMama.csv")

## cuál es el código ISO utilizado en el archivo?



## A continuación revisemos el contenido del archivo farmaco.txt

## Que separador utiliza?

## Qué función podemos aplicar?



#############

## Archivos Excel

## Activamos el paquete para hacer lecturas de archivos Excel

library(readxl)

## Tenemos un archivo de Excel para practicar, se llama datos.xlsx

## Ábranlo y vean el contenido de las tres hojas

# con la función excel_sheets() también podemos ver cuantas hojas tiene
# y como se llaman

excel_sheets(path = "datos.xlsx")

## Vamos con la primer hoja

datos1 <- read_excel(path = "datos.xlsx", sheet = 1)

# que es lo mismo que hacer:

datos1 <- read_excel("datos.xlsx")

# asume 1 en sheet de forma predeterminada

## Con la hoja 2 tenemos un problema

datos2 <- read_excel(path = "datos.xlsx", sheet = 2)

datos2

## Cómo se soluciona?



## Vamos con la tercera llamada Poblacion

## Hay dos tablas dentro de la misma hoja, cómo podemos hacer la lectura?


pob2010 <- read_excel(path = "datos.xlsx", 
                      sheet = "Poblacion", 
                      range = "A4:D25")
  
## Hacemos lo mismo para leer la otra tabla con range y guardarla como pob2021






######################

# Ahora guardemos el entorno completo de la sesión de trabajo

save(list = ls(), file = "lectoescritura.RData")

# usamos ls() para indicar que queremos todos los objetos del entorno

ls()

# muestra todos los nombres de los objetos

# para probar si efectivamente los guardó, vaciemos la memoria (escobita del 
# panel Environment) y ejecutemos lo siguiente:

load("lectoescritura.RData")

# lo mismo hace en forma automática la función save.image()

save.image(file = "lectoescritura.RData")

# también podemos guardar un objeto solo indicando su nombre en el argumento
# list del save()

save(dieta, file = "dieta.RData")

# probemos eliminando el dataframe y leyéndonlo nuevamente

rm(dieta)

load("dieta.RData")

#############

# Ahora guardemos en formato csv el dataframe datos1 (proviene de un Excel)

# bajo el nombre datos1_coma.csv en formato separador coma y en datos1_puntoycoma.csv 
# en formato separador punto y coma

write_csv(datos1, file = "datos1_coma.csv")

write_csv2(datos1, file = "datos1_puntoycoma.csv")

# revisemos desde el Panel Files la visualización de los contenidos de los archivos

## Lectura con arrow (parquet)

# Si el archivo es grande pero cabe en la memoria RAM
# de nuestro equipo podemos leerlo de forma completa

sisa <- read_parquet("bsas_2020-11-27/part-0.parquet")

# Si el archivo es muy grande y no cabe en la memoria RAM
# o está almacenado en una carpeta con varios fragmentos
# /particiones podemos leerlo en forma forma diferida o
# "perezosa".
# Podemos abrir un archivo CSV pesado como un dataset 
# de arrow (es muy rápido y eficiente en memoria)

sisa_diferido <- open_dataset("bsas_2020-11-27/part-0.parquet")

# Procesamos la consulta y extraemos los datos con collect()

resultado <- sisa_diferido |> 
  filter(PROVINCIA_RESIDENCIA == "Chubut") |> 
  collect()

resultado |> 
  count(PROVINCIA_RESIDENCIA)

# Para escribir archivos parquet se usa la función 
# write_dataset(), ya sea que hayamos leído un parquet o
# de cualquier otra forma, siempre y cuando el objeto sea
# un dataframe

write_dataset(dataset = resultado, 
              path = "resultado")


